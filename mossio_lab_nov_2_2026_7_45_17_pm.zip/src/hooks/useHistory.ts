import { useState, useEffect, useCallback } from 'react';
import { HistoryItem, HistoryItemType } from '../types';

const STORAGE_KEY = 'mossio_lab_history_v1';

export function useHistory() {
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Error loading history from localStorage', e);
    }
    // Default starter example items for MOSSIO LAB if fresh
    return [
      {
        id: 'hist-starter-1',
        type: 'prompt' as HistoryItemType,
        title: 'Cyberpunk Neon Alley at Dusk',
        snippet: 'Cinematic wide shot of rain-slicked Tokyo alleyway illuminated by holographic violet and cyan signage, 35mm lens, atmospheric mist...',
        fullData: {
          concept: 'Cyberpunk Neon Alley at Dusk',
          prompts: [
            {
              id: 'p-default',
              title: 'Master Atmospheric Cyber Alley',
              variantName: 'Production Master',
              mainPrompt: 'Cinematic wide shot of rain-slicked Tokyo alleyway illuminated by holographic violet and cyan signage, 35mm anamorphic prime lens, atmospheric mist, volumetric neon reflections, shallow depth of field, photorealistic, 8k --ar 16:9 --v 6.1 --style raw',
              technicalParameters: '--ar 16:9 --v 6.1 --style raw',
              whyItWorks: 'Combines exact optical lens specifications with color contrast and reflection layers.',
              tags: ['Cyberpunk', 'Cinematic', 'Neon', '35mm'],
            },
          ],
        },
        timestamp: Date.now() - 3600000,
        engine: 'Midjourney v6.1',
      },
      {
        id: 'hist-starter-2',
        type: 'improvement' as HistoryItemType,
        title: 'Minimalist Perfume Bottle on Stone',
        snippet: 'Rewritten from "a luxury perfume on a stone" to a master studio commercial advertising shot with travertine stone and diffused sunlight...',
        fullData: {
          original: 'a luxury perfume bottle on a stone with nice light',
          masterRewritten: 'Minimalist luxury aesthetic fragrance bottle in frosted smoked glass, rests on raw textured travertine slab, soft directional morning sunlight casting delicate geometric shadows, studio product photography, clean architectural styling, 85mm macro lens, ultra crisp detail',
          improvements: [
            'Replaced vague "nice light" with "soft directional morning sunlight casting delicate geometric shadows"',
            'Specified bottle material as "frosted smoked glass"',
            'Upgraded generic stone to "raw textured travertine slab" with 85mm macro camera framing',
          ],
        },
        timestamp: Date.now() - 7200000,
        engine: 'Prompt Rewriter',
      },
    ];
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch (e) {
      console.error('Error persisting history', e);
    }
  }, [history]);

  const addHistoryItem = useCallback((item: Omit<HistoryItem, 'id' | 'timestamp'>) => {
    const newItem: HistoryItem = {
      ...item,
      id: `hist-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      timestamp: Date.now(),
    };
    setHistory((prev) => [newItem, ...prev.slice(0, 99)]); // keep latest 100
    return newItem;
  }, []);

  const removeHistoryItem = useCallback((id: string) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const clearHistory = useCallback(() => {
    setHistory([]);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const exportHistoryJSON = useCallback(() => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(history, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `mossio-lab-creative-backup-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }, [history]);

  return {
    history,
    addHistoryItem,
    removeHistoryItem,
    clearHistory,
    exportHistoryJSON,
  };
}
