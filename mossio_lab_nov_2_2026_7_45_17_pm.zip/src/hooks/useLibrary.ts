import { useState, useEffect, useCallback } from 'react';
import { LibraryItem, LibraryItemType } from '../types';

const STORAGE_KEY = 'mossio_lab_library_v1';

const DEFAULT_STARTER_ITEMS: LibraryItem[] = [
  {
    id: 'lib-starter-1',
    type: 'prompt',
    title: 'Anamorphic Cyberpunk Neon Alley',
    content: 'Cinematic wide shot of rain-slicked Tokyo alleyway illuminated by holographic violet and cyan signage, 35mm anamorphic prime lens, atmospheric mist, volumetric neon reflections, shallow depth of field, 8k --ar 16:9 --v 6.1 --style raw',
    negativePrompt: 'daylight, cartoon, blurry, low resolution, flat lighting, text, watermark',
    category: 'Cyberpunk',
    tags: ['Midjourney', 'Cinematic', 'Neon', '35mm'],
    notes: 'Primary hero banner test prompt. Works exceptionally well on dark backgrounds.',
    isFavorite: true,
    createdAt: Date.now() - 86400000,
    updatedAt: Date.now() - 86400000,
  },
  {
    id: 'lib-starter-2',
    type: 'enhancement',
    title: 'Minimalist Frosted Perfume on Travertine',
    content: 'Minimalist luxury aesthetic fragrance bottle in frosted smoked glass, rests on raw textured travertine slab, soft directional morning sunlight casting delicate geometric shadows, studio product photography, clean architectural styling, 85mm macro lens, ultra crisp detail',
    negativePrompt: 'overcrowded, high contrast harsh sun, plastic, fingerprints, smudge',
    category: 'Commercial & Advertising',
    tags: ['Macro', 'Travertine', 'Product'],
    notes: 'Enhanced from a 1-sentence draft into commercial studio caliber.',
    isFavorite: true,
    createdAt: Date.now() - 43200000,
    updatedAt: Date.now() - 43200000,
  },
  {
    id: 'lib-starter-3',
    type: 'idea',
    title: 'Solitary Nomad Autonomous Speeders',
    content: 'Concept: A series of solar-recharging off-road motorcycles designed for trans-continental solo explorers traversing salt flats at twilight. Narrative hook: "Silence in the Dust."',
    recommendedPrompt: 'Matte carbon fiber aerodynamic desert speeder on cracked salt flats at twilight, golden hour rim reflections, cinematic documentary photography',
    category: 'Industrial Design',
    tags: ['Automotive', 'Solar', 'Campaign'],
    notes: 'Strategic campaign brief for mobility startup.',
    isFavorite: false,
    createdAt: Date.now() - 21600000,
    updatedAt: Date.now() - 21600000,
  } as any,
];

export function useLibrary() {
  const [items, setItems] = useState<LibraryItem[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (err) {
      console.warn('localStorage library read error (using defaults):', err);
    }
    return DEFAULT_STARTER_ITEMS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch (err) {
      console.warn('localStorage library write error:', err);
    }
  }, [items]);

  // Check if identical content exists to prevent duplicate saves
  const isDuplicate = useCallback(
    (content: string) => {
      const normalized = content.trim().toLowerCase();
      return items.some((item) => item.content.trim().toLowerCase() === normalized);
    },
    [items]
  );

  const addItem = useCallback(
    (item: {
      type: LibraryItemType;
      title: string;
      content: string;
      negativePrompt?: string;
      category?: string;
      tags?: string[];
      notes?: string;
      isFavorite?: boolean;
      metadata?: any;
    }) => {
      // Check for exact duplicate
      const normalized = item.content.trim().toLowerCase();
      const existing = items.find((i) => i.content.trim().toLowerCase() === normalized);
      if (existing) {
        return { item: existing, wasDuplicate: true };
      }

      const newItem: LibraryItem = {
        id: `lib-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        type: item.type,
        title: item.title.trim() || 'Untitled Creative Item',
        content: item.content.trim(),
        negativePrompt: item.negativePrompt?.trim(),
        category: item.category?.trim() || 'General',
        tags: item.tags || [],
        notes: item.notes?.trim() || '',
        isFavorite: Boolean(item.isFavorite),
        createdAt: Date.now(),
        updatedAt: Date.now(),
        metadata: item.metadata,
      };

      setItems((prev) => [newItem, ...prev]);
      return { item: newItem, wasDuplicate: false };
    },
    [items]
  );

  const updateItem = useCallback(
    (
      id: string,
      updates: Partial<Pick<LibraryItem, 'title' | 'content' | 'negativePrompt' | 'category' | 'tags' | 'notes' | 'isFavorite'>>
    ) => {
      setItems((prev) =>
        prev.map((item) =>
          item.id === id
            ? {
                ...item,
                ...updates,
                updatedAt: Date.now(),
              }
            : item
        )
      );
    },
    []
  );

  const toggleFavorite = useCallback((id: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              isFavorite: !item.isFavorite,
              updatedAt: Date.now(),
            }
          : item
      )
    );
  }, []);

  const deleteItem = useCallback((id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const clearLibrary = useCallback(() => {
    setItems([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (_) {}
  }, []);

  return {
    items,
    addItem,
    updateItem,
    toggleFavorite,
    deleteItem,
    clearLibrary,
    isDuplicate,
  };
}
