import { useState, useEffect, useCallback } from 'react';
import { Conversation, ChatMessage } from '../types';

const STORAGE_KEY = 'mossio_lab_conversations_v1';
const ACTIVE_ID_KEY = 'mossio_lab_active_conversation_id';

const DEFAULT_WELCOME_MESSAGE: ChatMessage = {
  id: 'msg-welcome-default',
  role: 'assistant',
  content:
    "Welcome to the MOSSIO LAB AI Chat Workspace. I'm your creative copilot and prompt architect. Ask me for Midjourney / FLUX camera setups, lighting rigs, visual storytelling, or prompt critiques.",
  timestamp: Date.now(),
};

function createInitialConversation(): Conversation {
  return {
    id: `conv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    title: 'New Creative Session',
    messages: [{ ...DEFAULT_WELCOME_MESSAGE, id: `msg-welcome-${Date.now()}` }],
    createdAt: Date.now(),
    updatedAt: Date.now(),
    creativeContext: '',
  };
}

export function useConversations() {
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (err) {
      console.warn('localStorage read error (using memory state):', err);
    }
    return [createInitialConversation()];
  });

  const [activeId, setActiveId] = useState<string>(() => {
    try {
      const storedId = localStorage.getItem(ACTIVE_ID_KEY);
      if (storedId && conversations.some((c) => c.id === storedId)) {
        return storedId;
      }
    } catch (_) {}
    return conversations[0]?.id || '';
  });

  // Keep localStorage synced safely
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations));
    } catch (err) {
      console.warn('localStorage write error:', err);
    }
  }, [conversations]);

  useEffect(() => {
    try {
      if (activeId) {
        localStorage.setItem(ACTIVE_ID_KEY, activeId);
      }
    } catch (_) {}
  }, [activeId]);

  const activeConversation =
    conversations.find((c) => c.id === activeId) || conversations[0] || createInitialConversation();

  const createNewConversation = useCallback((title = 'New Creative Session', context = '') => {
    const newConv: Conversation = {
      id: `conv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      title,
      messages: [{ ...DEFAULT_WELCOME_MESSAGE, id: `msg-welcome-${Date.now()}` }],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      creativeContext: context,
    };

    setConversations((prev) => [newConv, ...prev]);
    setActiveId(newConv.id);
    return newConv;
  }, []);

  const selectConversation = useCallback((id: string) => {
    setActiveId(id);
  }, []);

  const renameConversation = useCallback((id: string, newTitle: string) => {
    if (!newTitle.trim()) return;
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle.trim(), updatedAt: Date.now() } : c))
    );
  }, []);

  const deleteConversation = useCallback(
    (id: string) => {
      setConversations((prev) => {
        const remaining = prev.filter((c) => c.id !== id);
        if (remaining.length === 0) {
          const fresh = createInitialConversation();
          setActiveId(fresh.id);
          return [fresh];
        }
        if (activeId === id) {
          setActiveId(remaining[0].id);
        }
        return remaining;
      });
    },
    [activeId]
  );

  const clearCurrentMessages = useCallback((id: string) => {
    setConversations((prev) =>
      prev.map((c) =>
        c.id === id
          ? {
              ...c,
              messages: [
                {
                  id: `msg-welcome-${Date.now()}`,
                  role: 'assistant',
                  content: 'Chat session reset. What creative project or prompt are we exploring next?',
                  timestamp: Date.now(),
                },
              ],
              updatedAt: Date.now(),
            }
          : c
      )
    );
  }, []);

  const appendMessage = useCallback((convId: string, message: ChatMessage) => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id !== convId) return c;

        // Auto-generate a title if conversation is still on default title and user just sent their first prompt
        let updatedTitle = c.title;
        if (
          (c.title === 'New Creative Session' || c.title.trim() === '') &&
          message.role === 'user'
        ) {
          updatedTitle = message.content.slice(0, 32).trim() + (message.content.length > 32 ? '...' : '');
        }

        return {
          ...c,
          title: updatedTitle,
          messages: [...c.messages, message],
          updatedAt: Date.now(),
        };
      })
    );
  }, []);

  const updateCreativeContext = useCallback((convId: string, context: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === convId ? { ...c, creativeContext: context, updatedAt: Date.now() } : c))
    );
  }, []);

  return {
    conversations,
    activeConversation,
    activeId,
    createNewConversation,
    selectConversation,
    renameConversation,
    deleteConversation,
    clearCurrentMessages,
    appendMessage,
    updateCreativeContext,
  };
}
