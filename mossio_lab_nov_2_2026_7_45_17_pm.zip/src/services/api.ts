import {
  PromptGenerationResult,
  PromptImprovementResult,
  CreativeIdeasResult,
  ServerStatus,
  ConnectionTestResult,
} from '../types';

export class ApiError extends Error {
  code?: string;
  details?: string;

  constructor(message: string, code?: string, details?: string) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.details = details;
  }
}

async function handleResponse<T>(res: Response): Promise<T> {
  let data: any;
  try {
    data = await res.json();
  } catch (err) {
    throw new ApiError(`Server returned non-JSON response (${res.status})`, 'NETWORK_ERROR');
  }

  if (!res.ok) {
    throw new ApiError(
      data.message || 'An error occurred while processing the request',
      data.error || `HTTP_${res.status}`,
      data.details
    );
  }

  return data as T;
}

export async function fetchServerStatus(): Promise<ServerStatus> {
  const res = await fetch('/api/status');
  return handleResponse<ServerStatus>(res);
}

export async function testConnection(): Promise<ConnectionTestResult> {
  const res = await fetch('/api/test-connection', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  });
  return handleResponse<ConnectionTestResult>(res);
}

export async function generatePrompts(params: {
  concept: string;
  toolType: string;
  style: string;
  aspectRatio: string;
  mood: string;
  lighting: string;
  camera: string;
}): Promise<PromptGenerationResult> {
  const res = await fetch('/api/ai/generate-prompt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return handleResponse<PromptGenerationResult>(res);
}

export async function improvePrompt(params: {
  originalPrompt: string;
  targetGoal?: string;
  targetEngine?: string;
  language?: string;
}): Promise<PromptImprovementResult> {
  const res = await fetch('/api/ai/improve-prompt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return handleResponse<PromptImprovementResult>(res);
}

export async function generateCreativeIdeas(params: {
  topic: string;
  category: string;
  tone?: string;
  vibe?: string;
  targetAudience: string;
  count?: number;
}): Promise<CreativeIdeasResult> {
  const res = await fetch('/api/ai/creative-ideas', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return handleResponse<CreativeIdeasResult>(res);
}

export async function sendChatMessage(params: {
  messages: { role: 'user' | 'assistant'; content: string }[];
  creativeContext?: string;
}): Promise<{ reply: string }> {
  const res = await fetch('/api/ai/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return handleResponse<{ reply: string }>(res);
}
