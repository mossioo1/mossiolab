/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { ToolTab, ServerStatus } from './types';
import { fetchServerStatus } from './services/api';
import { useHistory } from './hooks/useHistory';
import { useLibrary } from './hooks/useLibrary';
import { Navbar } from './components/layout/Navbar';
import { SidebarDrawer } from './components/layout/SidebarDrawer';
import { BottomTabBar } from './components/layout/BottomTabBar';
import { DashboardOverview } from './components/dashboard/DashboardOverview';
import { PromptGenerator } from './components/tools/PromptGenerator';
import { PromptImprover } from './components/tools/PromptImprover';
import { IdeaGenerator } from './components/tools/IdeaGenerator';
import { ChatWorkspace } from './components/tools/ChatWorkspace';
import { LibraryView } from './components/tools/LibraryView';
import { HistoryView } from './components/tools/HistoryView';
import { SettingsView } from './components/tools/SettingsView';

export default function App() {
  const [currentTab, setCurrentTab] = useState<ToolTab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [serverStatus, setServerStatus] = useState<ServerStatus | null>(null);
  const [generatorConcept, setGeneratorConcept] = useState<string>('');

  const { history, addHistoryItem, removeHistoryItem, clearHistory, exportHistoryJSON } =
    useHistory();

  const {
    items: libraryItems,
    addItem: addToLibrary,
    updateItem: updateLibraryItem,
    toggleFavorite: toggleLibraryFavorite,
    deleteItem: deleteLibraryItem,
  } = useLibrary();

  const loadStatus = async () => {
    try {
      const status = await fetchServerStatus();
      setServerStatus(status);
    } catch (e) {
      console.error('Failed to load server status:', e);
      setServerStatus({
        status: 'offline',
        workspace: 'MOSSIO LAB',
        hasApiKey: false,
        model: 'gemini-3.8-flash',
        uptime: 0,
        timestamp: new Date().toISOString(),
      });
    }
  };

  useEffect(() => {
    loadStatus();
  }, []);

  const handlePopulatePrompt = (concept: string) => {
    setGeneratorConcept(concept);
    setCurrentTab('generator');
  };

  return (
    <div className="min-h-screen bg-[#060B19] text-slate-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        mobileMenuOpen={mobileMenuOpen}
        onToggleMobileMenu={() => setMobileMenuOpen((prev) => !prev)}
        serverStatus={serverStatus}
      />

      <div className="flex-1 flex w-full">
        {/* Responsive Desktop Sidebar / Mobile Drawer */}
        <SidebarDrawer
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          isOpen={mobileMenuOpen}
          onClose={() => setMobileMenuOpen(false)}
          historyCount={history.length}
          libraryCount={libraryItems.length}
        />

        {/* Main Content Area */}
        <main className="flex-1 w-full lg:pl-64 min-h-[calc(100vh-3.5rem)] pb-24 lg:pb-12">
          <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
            {currentTab === 'dashboard' && (
              <DashboardOverview
                onSelectTab={setCurrentTab}
                onPopulatePrompt={handlePopulatePrompt}
                history={history}
                serverStatus={serverStatus}
              />
            )}

            {currentTab === 'generator' && (
              <PromptGenerator
                initialConcept={generatorConcept}
                onSaveToHistory={addHistoryItem}
                onSaveToLibrary={addToLibrary}
                onOpenSettings={() => setCurrentTab('settings')}
                serverStatus={serverStatus}
              />
            )}

            {currentTab === 'improver' && (
              <PromptImprover
                onSaveToHistory={addHistoryItem}
                onSaveToLibrary={addToLibrary}
                onOpenSettings={() => setCurrentTab('settings')}
                serverStatus={serverStatus}
              />
            )}

            {currentTab === 'ideas' && (
              <IdeaGenerator
                onSaveToHistory={addHistoryItem}
                onSaveToLibrary={addToLibrary}
                onOpenSettings={() => setCurrentTab('settings')}
                serverStatus={serverStatus}
              />
            )}

            {currentTab === 'chat' && (
              <ChatWorkspace
                onSaveToHistory={addHistoryItem}
                onOpenSettings={() => setCurrentTab('settings')}
                serverStatus={serverStatus}
              />
            )}

            {currentTab === 'library' && (
              <LibraryView
                items={libraryItems}
                onUpdateItem={updateLibraryItem}
                onToggleFavorite={toggleLibraryFavorite}
                onDeleteItem={deleteLibraryItem}
                onSelectTab={setCurrentTab}
              />
            )}

            {currentTab === 'history' && (
              <HistoryView
                history={history}
                onRemoveItem={removeHistoryItem}
                onClearHistory={clearHistory}
                onExportJSON={exportHistoryJSON}
                onSelectTab={setCurrentTab}
              />
            )}

            {currentTab === 'settings' && (
              <SettingsView
                serverStatus={serverStatus}
                onRefreshStatus={loadStatus}
                historyCount={history.length}
                onExportJSON={exportHistoryJSON}
                onClearHistory={clearHistory}
              />
            )}
          </div>
        </main>
      </div>

      {/* Mobile-First Bottom Thumb Tab Bar (lg:hidden) */}
      <BottomTabBar currentTab={currentTab} onSelectTab={setCurrentTab} />
    </div>
  );
}
