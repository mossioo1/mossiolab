import {
  Sparkles,
  Wand2,
  Lightbulb,
  MessageSquare,
  History,
  Settings,
  LayoutDashboard,
  Layers,
  Flame,
  ArrowRight,
  ExternalLink,
  Info,
  FolderOpen,
} from 'lucide-react';
import { ToolTab } from '../../types';

interface SidebarDrawerProps {
  currentTab: ToolTab;
  onSelectTab: (tab: ToolTab) => void;
  isOpen: boolean;
  onClose: () => void;
  historyCount: number;
  libraryCount?: number;
}

export function SidebarDrawer({
  currentTab,
  onSelectTab,
  isOpen,
  onClose,
  historyCount,
  libraryCount = 0,
}: SidebarDrawerProps) {
  const navItems: { id: ToolTab; label: string; icon: any; tag?: string; desc: string }[] = [
    {
      id: 'dashboard',
      label: 'Studio Dashboard',
      icon: LayoutDashboard,
      desc: 'Workspace overview & quick stats',
    },
    {
      id: 'generator',
      label: 'Prompt Generator',
      icon: Sparkles,
      tag: 'Core',
      desc: 'Midjourney, FLUX & LLM prompts',
    },
    {
      id: 'improver',
      label: 'Prompt Improver',
      icon: Wand2,
      tag: 'Enhance',
      desc: 'Token optimization & style directions',
    },
    {
      id: 'ideas',
      label: 'Creative Idea Lab',
      icon: Lightbulb,
      tag: 'Brainstorm',
      desc: '7 creative categories & hooks',
    },
    {
      id: 'chat',
      label: 'AI Chat Workspace',
      icon: MessageSquare,
      desc: 'Creative director copilot',
    },
    {
      id: 'library',
      label: 'Prompt Library',
      icon: FolderOpen,
      tag: libraryCount > 0 ? String(libraryCount) : 'Vault',
      desc: 'Saved prompts, ideas & favorites',
    },
    {
      id: 'history',
      label: 'Recent History',
      icon: History,
      tag: historyCount > 0 ? String(historyCount) : undefined,
      desc: 'Past generations & bookmarks',
    },
    {
      id: 'settings',
      label: 'Settings & Status',
      icon: Settings,
      desc: 'Model diagnostics & theme',
    },
  ];

  const handleItemClick = (id: ToolTab) => {
    onSelectTab(id);
    onClose();
  };

  const navContent = (
    <div className="flex flex-col h-full bg-[#080E24] border-r border-slate-800/80">
      {/* Drawer Header for mobile */}
      <div className="p-4 sm:p-5 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-violet-600 flex items-center justify-center shadow-sm">
            <Layers className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="text-sm font-bold text-white tracking-tight">MOSSIO LAB</div>
            <div className="text-[10px] text-slate-400 font-mono">WORKSPACE SUITE</div>
          </div>
        </div>
      </div>

      {/* Nav Link List */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <div className="px-3 pb-2 text-[10px] font-semibold text-slate-400 uppercase tracking-wider font-mono">
          Creative Suites
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleItemClick(item.id)}
              className={`w-full text-left min-h-[48px] px-3.5 py-2.5 rounded-xl flex items-center gap-3 transition-all duration-150 active:scale-98 ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/15 via-blue-500/10 to-transparent text-cyan-300 border border-cyan-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                  isActive
                    ? 'bg-cyan-500/20 text-cyan-400'
                    : 'bg-slate-850 text-slate-400 group-hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold truncate tracking-tight">{item.label}</span>
                  {item.tag && (
                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                        isActive
                          ? 'bg-cyan-500/30 text-cyan-200'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.tag}
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 truncate">{item.desc}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Mobile-Friendly Android Dev Card */}
      <div className="p-3 m-3 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 text-xs">
        <div className="flex items-center gap-2 text-cyan-300 font-semibold mb-1 text-[11px]">
          <Flame className="w-3.5 h-3.5 text-cyan-400" />
          <span>Android Mobile Mode</span>
        </div>
        <p className="text-[10px] text-slate-400 leading-relaxed">
          Optimized for Android Chrome &amp; mobile previews. Single-tap copy and swipe-friendly drawers.
        </p>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 fixed top-16 left-0 bottom-0 z-20">
        {navContent}
      </aside>

      {/* Mobile Drawer Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
            onClick={onClose}
            aria-hidden="true"
          />

          {/* Drawer Body (slides from left) */}
          <div className="relative w-[280px] max-w-[85vw] h-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {navContent}
          </div>
        </div>
      )}
    </>
  );
}
