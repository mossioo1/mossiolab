import {
  LayoutDashboard,
  Sparkles,
  Wand2,
  Lightbulb,
  MessageSquare,
} from 'lucide-react';
import { ToolTab } from '../../types';

interface BottomTabBarProps {
  currentTab: ToolTab;
  onSelectTab: (tab: ToolTab) => void;
}

export function BottomTabBar({ currentTab, onSelectTab }: BottomTabBarProps) {
  const tabs: { id: ToolTab; label: string; icon: any }[] = [
    { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
    { id: 'generator', label: 'Prompt', icon: Sparkles },
    { id: 'improver', label: 'Rewrite', icon: Wand2 },
    { id: 'ideas', label: 'Ideas', icon: Lightbulb },
    { id: 'chat', label: 'Chat', icon: MessageSquare },
  ];

  return (
    <nav
      aria-label="Mobile Navigation"
      className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-[#060B19]/95 backdrop-blur-lg border-t border-slate-800/90 pb-safe shadow-2xl"
    >
      <div className="grid grid-cols-5 items-center h-14 max-w-lg mx-auto px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onSelectTab(tab.id)}
              className={`min-h-[44px] flex flex-col items-center justify-center transition-all duration-150 active:scale-90 relative ${
                isActive ? 'text-cyan-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform duration-200 ${isActive ? 'scale-110' : ''}`} />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_6px_#22d3ee]" />
                )}
              </div>
              <span className="text-[10px] tracking-tight mt-1 truncate max-w-full px-1">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
