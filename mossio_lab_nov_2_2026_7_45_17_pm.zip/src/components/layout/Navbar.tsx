import { Sparkles, Menu, X, Terminal, Radio } from 'lucide-react';
import { ToolTab, ServerStatus } from '../../types';

interface NavbarProps {
  currentTab: ToolTab;
  onSelectTab: (tab: ToolTab) => void;
  mobileMenuOpen: boolean;
  onToggleMobileMenu: () => void;
  serverStatus: ServerStatus | null;
}

export function Navbar({
  currentTab,
  onSelectTab,
  mobileMenuOpen,
  onToggleMobileMenu,
  serverStatus,
}: NavbarProps) {
  const isOnline = serverStatus?.hasApiKey;

  return (
    <header className="sticky top-0 z-40 w-full bg-[#060B19]/90 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-4">
      {/* Brand Zone */}
      <div className="flex items-center gap-3">
        {/* Mobile menu hamburger (min-h-[44px] min-w-[44px]) */}
        <button
          type="button"
          onClick={onToggleMobileMenu}
          aria-label={mobileMenuOpen ? 'Close navigation drawer' : 'Open navigation drawer'}
          className="lg:hidden min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 active:scale-95 transition-all"
        >
          {mobileMenuOpen ? <X className="w-5 h-5 text-cyan-400" /> : <Menu className="w-5 h-5" />}
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('dashboard')}
          className="flex items-center gap-2.5 text-left group transition-transform active:scale-98"
        >
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-violet-600 p-[1px] shadow-sm">
            <div className="w-full h-full bg-[#060B19] rounded-[11px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-cyan-400 group-hover:rotate-12 transition-transform duration-300" />
            </div>
          </div>
          <div>
            <span className="font-display font-extrabold text-base sm:text-lg tracking-tight text-white group-hover:text-cyan-300 transition-colors">
              MOSSIO<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-violet-400">LAB</span>
            </span>
            <div className="hidden sm:flex items-center gap-1.5 text-[10px] text-slate-400 tracking-wider font-mono">
              <span>CREATIVE WORKSPACE</span>
              <span className="text-slate-600">·</span>
              <span>v1.0</span>
            </div>
          </div>
        </button>
      </div>

      {/* Desktop Quick Nav Links */}
      <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold tracking-wide text-slate-300">
        <button
          onClick={() => onSelectTab('dashboard')}
          className={`hover:text-cyan-300 transition-colors ${currentTab === 'dashboard' ? 'text-cyan-400' : ''}`}
        >
          Overview
        </button>
        <button
          onClick={() => onSelectTab('generator')}
          className={`hover:text-cyan-300 transition-colors ${currentTab === 'generator' ? 'text-cyan-400' : ''}`}
        >
          Prompt Generator
        </button>
        <button
          onClick={() => onSelectTab('improver')}
          className={`hover:text-cyan-300 transition-colors ${currentTab === 'improver' ? 'text-cyan-400' : ''}`}
        >
          Rewriter
        </button>
        <button
          onClick={() => onSelectTab('ideas')}
          className={`hover:text-cyan-300 transition-colors ${currentTab === 'ideas' ? 'text-cyan-400' : ''}`}
        >
          Idea Lab
        </button>
        <button
          onClick={() => onSelectTab('chat')}
          className={`hover:text-cyan-300 transition-colors ${currentTab === 'chat' ? 'text-cyan-400' : ''}`}
        >
          AI Chat
        </button>
        <button
          onClick={() => onSelectTab('library')}
          className={`hover:text-cyan-300 transition-colors ${currentTab === 'library' ? 'text-cyan-400' : ''}`}
        >
          Library
        </button>
        <button
          onClick={() => onSelectTab('history')}
          className={`hover:text-cyan-300 transition-colors ${currentTab === 'history' ? 'text-cyan-400' : ''}`}
        >
          History
        </button>
      </nav>

      {/* Status & Actions Zone */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Model status indicator */}
        <button
          type="button"
          onClick={() => onSelectTab('settings')}
          className="min-h-[40px] px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 flex items-center gap-2 transition-all active:scale-95"
          title={isOnline ? `${serverStatus?.model || 'gemini-3.1-flash-lite'} Active` : 'API Key Setup Needed'}
        >
          <div className="relative flex items-center justify-center">
            <span
              className={`w-2 h-2 rounded-full ${
                isOnline ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]' : 'bg-amber-400 shadow-[0_0_8px_#fbbf24]'
              }`}
            />
          </div>
          <span className="hidden sm:inline text-[11px] font-mono font-medium text-slate-300">
            {isOnline ? serverStatus?.model || 'gemini-3.1-flash-lite' : 'Setup Key'}
          </span>
          <span className="sm:hidden text-[11px] font-mono text-slate-300">
            {isOnline ? 'AI' : 'Setup'}
          </span>
        </button>

        {/* Create CTA Button */}
        <button
          type="button"
          onClick={() => onSelectTab('generator')}
          className="min-h-[40px] px-3 sm:px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs tracking-wide transition-all shadow-md glow-cyan active:scale-95 flex items-center gap-1.5 shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden xs:inline">New Prompt</span>
          <span className="xs:hidden">New</span>
        </button>
      </div>
    </header>
  );
}
