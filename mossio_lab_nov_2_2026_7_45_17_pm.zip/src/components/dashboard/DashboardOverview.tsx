import {
  Sparkles,
  Wand2,
  Lightbulb,
  MessageSquare,
  ArrowRight,
  Zap,
  Layers,
  History,
  TrendingUp,
  Cpu,
  Clock,
  Compass,
} from 'lucide-react';
import { ToolTab, HistoryItem, ServerStatus } from '../../types';
import { CopyButton } from '../common/CopyButton';
import { ApiKeyBanner } from '../common/ApiKeyBanner';

interface DashboardOverviewProps {
  onSelectTab: (tab: ToolTab) => void;
  onPopulatePrompt?: (concept: string, engine?: string) => void;
  history: HistoryItem[];
  serverStatus: ServerStatus | null;
}

export function DashboardOverview({
  onSelectTab,
  onPopulatePrompt,
  history,
  serverStatus,
}: DashboardOverviewProps) {
  const quickActions = [
    {
      id: 'generator' as ToolTab,
      title: 'Prompt Generator',
      subtitle: 'Engine-tuned prompts for Midjourney, FLUX & LLMs',
      icon: Sparkles,
      color: 'from-cyan-500 to-blue-600',
      badge: 'Most Popular',
      glow: 'hover:border-cyan-500/50 hover:shadow-[0_0_20px_rgba(6,182,212,0.2)]',
    },
    {
      id: 'improver' as ToolTab,
      title: 'Prompt Rewriter',
      subtitle: 'Upgrade weak or vague prompts into studio masterworks',
      icon: Wand2,
      color: 'from-violet-500 to-fuchsia-600',
      badge: 'Optimization',
      glow: 'hover:border-violet-500/50 hover:shadow-[0_0_20px_rgba(168,85,247,0.2)]',
    },
    {
      id: 'ideas' as ToolTab,
      title: 'Creative Idea Lab',
      subtitle: 'Campaign hooks, naming concepts & visual directions',
      icon: Lightbulb,
      color: 'from-amber-500 to-orange-600',
      badge: 'Brainstorm',
      glow: 'hover:border-amber-500/50 hover:shadow-[0_0_20px_rgba(245,158,11,0.2)]',
    },
    {
      id: 'chat' as ToolTab,
      title: 'AI Chat Copilot',
      subtitle: 'Conversational studio director and prompt architect',
      icon: MessageSquare,
      color: 'from-emerald-500 to-teal-600',
      badge: 'Interactive',
      glow: 'hover:border-emerald-500/50 hover:shadow-[0_0_20px_rgba(16,185,129,0.2)]',
    },
  ];

  const sampleInspirations = [
    {
      title: 'Cinematic Cyberpunk Rain Street',
      category: 'Midjourney v6.1',
      concept: 'Rain-slicked Tokyo neon back-alley with holographic signage and steam vents, 35mm lens',
    },
    {
      title: 'Minimalist Architectural Perfume Bottle',
      category: 'FLUX.1 Dev',
      concept: 'Luxury fragrance bottle in smoked frosted glass resting on raw travertine slab in morning light',
    },
    {
      title: 'Iridescent Abstract Fluid Dynamics',
      category: 'Creative Art',
      concept: 'Swirling high-viscosity chromatic liquid titanium sculpture suspended in black void, studio rim light',
    },
    {
      title: 'Futuristic Solar Hovercraft Prototype',
      category: 'Industrial Design',
      concept: 'Matte carbon fiber aerodynamic speeder parked on salt flats at twilight, golden hour reflection',
    },
  ];

  return (
    <div className="space-y-6 sm:space-y-8 animate-fadeIn max-w-6xl mx-auto">
      {/* Missing API Key notice if needed */}
      {!serverStatus?.hasApiKey && (
        <ApiKeyBanner onOpenSettings={() => onSelectTab('settings')} />
      )}

      {/* Hero Studio Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0B1437] via-[#080E26] to-[#040816] border border-cyan-500/25 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-80 h-80 bg-gradient-to-br from-cyan-500/10 via-violet-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-mono font-medium mb-3">
              <Zap className="w-3.5 h-3.5" />
              <span>MOSSIO LAB v1.0 · MOBILE STUDIO</span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight">
              Elevate Your Creative AI Vision.
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
              Engineer high-fidelity prompts, optimize lighting and camera tokens, and ideate next-generation campaigns from your Android browser.
            </p>
          </div>

          <div className="flex flex-wrap sm:flex-col gap-3 shrink-0">
            <button
              type="button"
              onClick={() => onSelectTab('generator')}
              className="min-h-[48px] px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs sm:text-sm tracking-wide shadow-lg glow-cyan active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Launch Prompt Studio</span>
            </button>
            <button
              type="button"
              onClick={() => onSelectTab('improver')}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-slate-200 font-semibold text-xs transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <Wand2 className="w-4 h-4 text-violet-400" />
              <span>Improve Existing Prompt</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Access Tool Cards Grid */}
      <div>
        <div className="flex items-center justify-between mb-3.5">
          <h2 className="text-sm font-bold tracking-tight text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>Creative Suites</span>
          </h2>
          <span className="text-[11px] font-mono text-slate-400">4 Core Workspaces</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
          {quickActions.map((tool) => {
            const Icon = tool.icon;
            return (
              <div
                key={tool.id}
                onClick={() => onSelectTab(tool.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === 'Enter' && onSelectTab(tool.id)}
                className={`group cursor-pointer p-4 sm:p-5 rounded-2xl bg-[#0B132B]/80 border border-slate-800/90 transition-all duration-200 active:scale-98 ${tool.glow} flex flex-col justify-between`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${tool.color} flex items-center justify-center text-white shadow-sm`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono text-slate-400 group-hover:text-cyan-300 transition-colors">
                      {tool.badge}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {tool.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed line-clamp-2">
                    {tool.subtitle}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs font-semibold text-slate-300 group-hover:text-cyan-400 transition-colors">
                  <span>Open workspace</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Instant Inspiration Presets (1-tap populate for mobile users!) */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#091029]/80 border border-slate-800/80">
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Instant Inspiration Starter Ideas</h3>
          </div>
          <span className="text-[10px] font-mono text-slate-400">1-Tap to Generate</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {sampleInspirations.map((item, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800/80 hover:border-cyan-500/40 transition-all flex items-start justify-between gap-3 group"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-cyan-400 font-medium">
                    {item.category}
                  </span>
                </div>
                <h4 className="text-xs font-semibold text-slate-100 group-hover:text-cyan-200 mt-0.5 truncate">
                  {item.title}
                </h4>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {item.concept}
                </p>
              </div>

              <div className="flex items-center gap-1 shrink-0 self-center">
                <CopyButton text={item.concept} iconOnly className="min-h-[38px] min-w-[38px]" />
                <button
                  type="button"
                  onClick={() => {
                    if (onPopulatePrompt) {
                      onPopulatePrompt(item.concept, item.category);
                    }
                    onSelectTab('generator');
                  }}
                  title="Load into Prompt Generator"
                  className="min-h-[38px] px-2.5 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1 active:scale-95 transition-all"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Use</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity Strip */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#091029]/80 border border-slate-800/80">
        <div className="flex items-center justify-between mb-3.5">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-violet-400" />
            <h3 className="text-sm font-bold text-white">Recent Studio Creations</h3>
          </div>
          <button
            type="button"
            onClick={() => onSelectTab('history')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
          >
            <span>View All ({history.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {history.length === 0 ? (
          <p className="text-xs text-slate-400 py-4 text-center">
            No creations yet. Generate your first prompt or creative concept above!
          </p>
        ) : (
          <div className="space-y-2.5">
            {history.slice(0, 3).map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/70 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                      {item.type}
                    </span>
                    <span className="text-xs font-semibold text-slate-200 truncate">
                      {item.title}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">{item.snippet}</p>
                </div>
                <CopyButton
                  text={item.snippet}
                  iconOnly
                  className="min-h-[38px] min-w-[38px] shrink-0"
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
