import { LucideIcon, Sparkles } from 'lucide-react';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  accentColor?: 'cyan' | 'violet' | 'amber';
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
  accentColor = 'cyan',
}: EmptyStateProps) {
  const colorMap = {
    cyan: {
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500/20',
      icon: 'text-cyan-400',
      btn: 'bg-cyan-500 hover:bg-cyan-400 text-slate-950',
    },
    violet: {
      bg: 'bg-violet-500/10',
      border: 'border-violet-500/20',
      icon: 'text-violet-400',
      btn: 'bg-violet-600 hover:bg-violet-500 text-white',
    },
    amber: {
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/20',
      icon: 'text-amber-400',
      btn: 'bg-amber-500 hover:bg-amber-400 text-slate-950',
    },
  };

  const scheme = colorMap[accentColor];

  return (
    <div className="flex flex-col items-center justify-center text-center p-8 sm:p-12 rounded-2xl bg-[#0B132B]/50 border border-slate-800/80">
      <div className={`w-14 h-14 rounded-2xl ${scheme.bg} ${scheme.border} border flex items-center justify-center mb-4 shadow-sm`}>
        <Icon className={`w-7 h-7 ${scheme.icon}`} />
      </div>
      <h3 className="text-base font-semibold text-white mb-1.5">{title}</h3>
      <p className="text-xs text-slate-400 max-w-md leading-relaxed mb-5">{description}</p>
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className={`min-h-[44px] px-5 py-2.5 rounded-xl font-semibold text-xs tracking-wide transition-all shadow-md active:scale-95 flex items-center gap-2 ${scheme.btn}`}
        >
          <Sparkles className="w-4 h-4" />
          <span>{actionLabel}</span>
        </button>
      )}
    </div>
  );
}
