import { Sparkles } from 'lucide-react';

interface LoadingSkeletonProps {
  title?: string;
  subtitle?: string;
  cardsCount?: number;
}

export function LoadingSkeleton({
  title = 'Synthesizing with MOSSIO Engine...',
  subtitle = 'Evaluating tokens, atmospheric depth, and composition parameters',
  cardsCount = 3,
}: LoadingSkeletonProps) {
  return (
    <div className="w-full space-y-4 py-4 animate-fadeIn">
      {/* Active pulse header */}
      <div className="flex items-center gap-3 p-4 rounded-2xl bg-[#0B132B]/90 border border-cyan-500/30 shadow-lg glow-cyan">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-violet-600 flex items-center justify-center animate-spin" style={{ animationDuration: '3s' }}>
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <h4 className="text-sm font-semibold text-white flex items-center gap-2">
            {title}
            <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          </h4>
          <p className="text-xs text-slate-400">{subtitle}</p>
        </div>
      </div>

      {/* Placeholder skeleton cards */}
      <div className="space-y-3">
        {Array.from({ length: cardsCount }).map((_, i) => (
          <div
            key={i}
            className="p-4 rounded-2xl bg-[#0B132B]/60 border border-slate-800/80 space-y-3 animate-pulse"
            style={{ animationDelay: `${i * 150}ms` }}
          >
            <div className="flex items-center justify-between">
              <div className="h-4 w-40 bg-slate-700/60 rounded" />
              <div className="h-6 w-20 bg-slate-800 rounded-lg" />
            </div>
            <div className="space-y-2">
              <div className="h-3 w-full bg-slate-700/40 rounded" />
              <div className="h-3 w-5/6 bg-slate-700/40 rounded" />
              <div className="h-3 w-2/3 bg-slate-700/30 rounded" />
            </div>
            <div className="flex gap-2 pt-1">
              <div className="h-5 w-16 bg-slate-800/80 rounded" />
              <div className="h-5 w-20 bg-slate-800/80 rounded" />
              <div className="h-5 w-14 bg-slate-800/80 rounded" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
