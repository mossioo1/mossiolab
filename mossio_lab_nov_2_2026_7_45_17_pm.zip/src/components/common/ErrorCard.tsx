import { AlertTriangle, RefreshCw, KeyRound } from 'lucide-react';

interface ErrorCardProps {
  title?: string;
  message: string;
  code?: string;
  onRetry?: () => void;
  onOpenSettings?: () => void;
}

export function ErrorCard({
  title = 'Creative Synthesis Interrupted',
  message,
  code,
  onRetry,
  onOpenSettings,
}: ErrorCardProps) {
  const isKeyError = code === 'API_KEY_NOT_CONFIGURED' || message.includes('API key');

  return (
    <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-500/40 text-slate-100 shadow-lg space-y-3">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center shrink-0">
          <AlertTriangle className="w-5 h-5 text-rose-400" />
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-semibold text-rose-200">{title}</h4>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed break-words">{message}</p>
          {code && (
            <p className="text-[11px] font-mono text-rose-400/80 mt-1">Code: {code}</p>
          )}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2.5 pt-2 border-t border-rose-500/20">
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-200 text-xs font-semibold flex items-center gap-2 transition-all active:scale-95"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Try Again</span>
          </button>
        )}
        {isKeyError && onOpenSettings && (
          <button
            type="button"
            onClick={onOpenSettings}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 text-xs font-semibold flex items-center gap-2 transition-all active:scale-95"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Configure AI Credentials</span>
          </button>
        )}
      </div>
    </div>
  );
}
