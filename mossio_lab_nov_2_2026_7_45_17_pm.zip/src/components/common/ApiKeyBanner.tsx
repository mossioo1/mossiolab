import { KeyRound, ShieldAlert, Sparkles, ExternalLink } from 'lucide-react';

interface ApiKeyBannerProps {
  onOpenSettings?: () => void;
  compact?: boolean;
}

export function ApiKeyBanner({ onOpenSettings, compact = false }: ApiKeyBannerProps) {
  if (compact) {
    return (
      <div className="flex items-center justify-between gap-3 p-3 bg-amber-500/10 border border-amber-500/25 rounded-xl text-xs text-amber-200">
        <div className="flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Gemini API Key needed for live AI generation</span>
        </div>
        {onOpenSettings && (
          <button
            onClick={onOpenSettings}
            className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-medium rounded-lg transition-colors shrink-0"
          >
            Setup Guide
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900/90 to-purple-950/40 border border-amber-500/30 p-5 shadow-lg">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center shrink-0 mt-0.5 sm:mt-0">
            <KeyRound className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-amber-200 flex items-center gap-2">
              Gemini API Key Setup Required
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                Action Needed
              </span>
            </h4>
            <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
              MOSSIO LAB integrates with Google Gemini 3.8 Flash on the secure server side. To activate real-time generation, add your API key in the <strong className="text-white">Settings &gt; Secrets</strong> panel in the AI Studio header (or specify <code className="text-cyan-300 font-mono">GEMINI_API_KEY</code> in <code className="text-cyan-300 font-mono">.env</code>).
            </p>
          </div>
        </div>

        {onOpenSettings && (
          <button
            type="button"
            onClick={onOpenSettings}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs tracking-wide transition-all shadow-md active:scale-95 flex items-center gap-2 shrink-0 self-stretch sm:self-auto justify-center"
          >
            <Sparkles className="w-4 h-4 text-slate-950" />
            <span>Open Setup Guide</span>
          </button>
        )}
      </div>
    </div>
  );
}
