import { useState } from 'react';
import {
  FolderOpen,
  Search,
  Star,
  Edit2,
  Trash2,
  Clock,
  Sparkles,
  Wand2,
  Lightbulb,
  X,
  Check,
  Shield,
  Download,
  AlertCircle,
  Tag,
  Filter,
} from 'lucide-react';
import { LibraryItem, LibraryItemType } from '../../types';
import { CopyButton } from '../common/CopyButton';
import { EmptyState } from '../common/EmptyState';

interface LibraryViewProps {
  items: LibraryItem[];
  onToggleFavorite: (id: string) => void;
  onDeleteItem: (id: string) => void;
  onUpdateItem: (
    id: string,
    updates: Partial<Pick<LibraryItem, 'title' | 'content' | 'negativePrompt' | 'category' | 'tags' | 'notes' | 'isFavorite'>>
  ) => void;
  onSelectTab: (tab: any) => void;
}

export function LibraryView({
  items,
  onToggleFavorite,
  onDeleteItem,
  onUpdateItem,
  onSelectTab,
}: LibraryViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'prompt' | 'enhancement' | 'idea' | 'favorites'>('all');
  const [editingItem, setEditingItem] = useState<LibraryItem | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Filter items
  const filteredItems = items.filter((item) => {
    // Category check
    if (activeCategory === 'favorites' && !item.isFavorite) return false;
    if (activeCategory !== 'all' && activeCategory !== 'favorites' && item.type !== activeCategory) return false;

    // Search query check
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchContent = item.content.toLowerCase().includes(q);
      const matchNotes = item.notes?.toLowerCase().includes(q);
      const matchTags = item.tags?.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchContent && !matchNotes && !matchTags) return false;
    }

    return true;
  });

  const getIcon = (type: LibraryItemType) => {
    switch (type) {
      case 'prompt':
        return <Sparkles className="w-3.5 h-3.5 text-cyan-400" />;
      case 'enhancement':
        return <Wand2 className="w-3.5 h-3.5 text-violet-400" />;
      case 'idea':
        return <Lightbulb className="w-3.5 h-3.5 text-amber-400" />;
    }
  };

  const formatTime = (ts: number) => {
    const diff = Math.floor((Date.now() - ts) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    onUpdateItem(editingItem.id, {
      title: editingItem.title.trim(),
      content: editingItem.content.trim(),
      negativePrompt: editingItem.negativePrompt?.trim(),
      category: editingItem.category.trim(),
      notes: editingItem.notes?.trim(),
    });

    setEditingItem(null);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-mono font-medium mb-1">
            <FolderOpen className="w-3.5 h-3.5" />
            <span>STUDIO VAULT</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
            Prompt &amp; Idea Library
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Curate, organize, edit, and access your high-performing studio prompts and concept briefs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-cyan-300 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl">
            {items.length} Saved {items.length === 1 ? 'Asset' : 'Assets'}
          </span>
        </div>
      </div>

      {/* Search and Category Filter Toolbar */}
      <div className="p-4 rounded-2xl bg-[#0B132B]/90 border border-slate-800 space-y-3 shadow-lg">
        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search saved prompts, notes, categories, keywords..."
            className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-cyan-500 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 outline-none transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {(
            [
              { id: 'all', label: `All Assets (${items.length})` },
              { id: 'favorites', label: `Favorites (${items.filter((i) => i.isFavorite).length})` },
              { id: 'prompt', label: `Prompts (${items.filter((i) => i.type === 'prompt').length})` },
              { id: 'enhancement', label: `Enhancements (${items.filter((i) => i.type === 'enhancement').length})` },
              { id: 'idea', label: `Ideas (${items.filter((i) => i.type === 'idea').length})` },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveCategory(tab.id)}
              className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all active:scale-95 flex items-center gap-1.5 ${
                activeCategory === tab.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {tab.id === 'favorites' && <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Library Items List */}
      {filteredItems.length === 0 ? (
        <EmptyState
          icon={FolderOpen}
          title={searchQuery ? 'No matching assets found' : 'Your Library is Empty'}
          description={
            searchQuery
              ? 'Try modifying your search term or selecting another category filter.'
              : 'Save prompts from the Prompt Generator, Prompt Enhancer, or Idea Generator to build your personal studio vault.'
          }
          actionLabel="Open Prompt Enhancer"
          onAction={() => onSelectTab('improver')}
          accentColor="cyan"
        />
      ) : (
        <div className="space-y-3.5">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="p-4 sm:p-5 rounded-2xl bg-[#0B132B] border border-slate-800 hover:border-slate-700/80 transition-all shadow-md space-y-3 group"
            >
              {/* Item Top Row */}
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 uppercase">
                      {getIcon(item.type)}
                      <span>{item.type}</span>
                    </span>

                    {item.category && (
                      <span className="text-[10px] font-mono text-cyan-400">
                        {item.category}
                      </span>
                    )}

                    <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{formatTime(item.createdAt)}</span>
                    </span>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-white group-hover:text-cyan-200 transition-colors">
                    {item.title}
                  </h3>
                </div>

                {/* Star & Action buttons */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(item.id)}
                    title={item.isFavorite ? 'Remove from favorites' : 'Mark as favorite'}
                    className={`min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border transition-all ${
                      item.isFavorite
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                        : 'bg-slate-900 text-slate-400 hover:text-amber-300 border-slate-800'
                    }`}
                  >
                    <Star className={`w-4 h-4 ${item.isFavorite ? 'fill-amber-400' : ''}`} />
                  </button>

                  <button
                    type="button"
                    onClick={() => setEditingItem(item)}
                    title="Edit asset details"
                    className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 border border-slate-800 transition-all active:scale-95"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeleteConfirmId(item.id)}
                    title="Delete asset"
                    className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl bg-slate-900 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-800 transition-all active:scale-95"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Main Content Box */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-850 font-mono text-xs text-slate-200 leading-relaxed select-all break-words">
                {item.content}
              </div>

              {/* Negative Prompt if present */}
              {item.negativePrompt && (
                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <span className="text-[10px] font-mono text-rose-400 block font-semibold">
                      Negative Prompt:
                    </span>
                    <span className="font-mono text-[11px] text-slate-300 truncate block">
                      {item.negativePrompt}
                    </span>
                  </div>
                  <CopyButton text={item.negativePrompt} label="Copy Negative" className="min-h-[30px] px-2 py-1 text-[10px]" />
                </div>
              )}

              {/* Notes & Tags row */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/60">
                <div className="flex flex-wrap items-center gap-1.5">
                  {item.notes && (
                    <span className="text-[11px] text-slate-400 italic">
                      Note: {item.notes}
                    </span>
                  )}
                  {item.tags && item.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {item.tags.map((t, tIdx) => (
                        <span
                          key={tIdx}
                          className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800"
                        >
                          #{t}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <CopyButton text={item.content} label="Copy Prompt" className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit Item Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
            onClick={() => setEditingItem(null)}
          />
          <div className="relative w-full max-w-lg rounded-2xl bg-[#0B132B] border border-cyan-500/40 p-5 sm:p-6 shadow-2xl space-y-4 z-10 max-h-[90vh] overflow-y-auto animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-cyan-400" />
                <span>Edit Library Asset</span>
              </h3>
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-300 mb-1">
                  Title
                </label>
                <input
                  type="text"
                  value={editingItem.title}
                  onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-300 mb-1">
                  Prompt / Content
                </label>
                <textarea
                  rows={4}
                  value={editingItem.content}
                  onChange={(e) => setEditingItem({ ...editingItem, content: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-300 mb-1">
                  Negative Prompt (Optional)
                </label>
                <input
                  type="text"
                  value={editingItem.negativePrompt || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, negativePrompt: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-mono text-slate-300 mb-1">
                    Category
                  </label>
                  <input
                    type="text"
                    value={editingItem.category}
                    onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono text-slate-300 mb-1">
                    Notes
                  </label>
                  <input
                    type="text"
                    value={editingItem.notes || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, notes: e.target.value })}
                    placeholder="e.g. Best for 16:9 Midjourney renders"
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="flex-1 min-h-[40px] rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 min-h-[40px] rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold shadow-md"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
            onClick={() => setDeleteConfirmId(null)}
          />
          <div className="relative w-full max-w-sm rounded-2xl bg-[#0B132B] border border-rose-500/40 p-5 shadow-2xl space-y-3 z-10 animate-in zoom-in-95 duration-150">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-base font-bold text-white">Delete Library Asset?</h4>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                This item will be permanently removed from your saved prompt library.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 min-h-[40px] rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteItem(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="flex-1 min-h-[40px] rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
