import { useState } from 'react';
import {
  Sparkles,
  Sliders,
  Ratio,
  Camera,
  Sun,
  Flame,
  Zap,
  BookmarkCheck,
  Check,
  RefreshCw,
  Tag,
  ChevronDown,
  Info,
} from 'lucide-react';
import { generatePrompts, ApiError } from '../../services/api';
import { PromptGenerationResult, GeneratedPrompt, ServerStatus, LibraryItem } from '../../types';
import { CopyButton } from '../common/CopyButton';
import { LoadingSkeleton } from '../common/LoadingSkeleton';
import { ErrorCard } from '../common/ErrorCard';
import { ApiKeyBanner } from '../common/ApiKeyBanner';

interface PromptGeneratorProps {
  initialConcept?: string;
  onSaveToHistory: (item: {
    type: 'prompt';
    title: string;
    snippet: string;
    fullData: any;
    engine?: string;
  }) => void;
  onSaveToLibrary?: (item: {
    type: 'prompt';
    title: string;
    content: string;
    negativePrompt?: string;
    parameters?: string;
    category?: string;
    tags?: string[];
  }) => { item: LibraryItem; wasDuplicate: boolean };
  onOpenSettings?: () => void;
  serverStatus: ServerStatus | null;
}

export function PromptGenerator({
  initialConcept = '',
  onSaveToHistory,
  onSaveToLibrary,
  onOpenSettings,
  serverStatus,
}: PromptGeneratorProps) {
  const [concept, setConcept] = useState(initialConcept);
  const [toolType, setToolType] = useState('Midjourney v6.1');
  const [style, setStyle] = useState('Cinematic 35mm Film');
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [mood, setMood] = useState('Dramatic & Atmospheric');
  const [lighting, setLighting] = useState('Volumetric neon rim light');
  const [camera, setCamera] = useState('35mm anamorphic prime lens, shallow DOF');
  const [showAdvanced, setShowAdvanced] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<{ message: string; code?: string } | null>(null);
  const [result, setResult] = useState<PromptGenerationResult | null>(null);
  const [savedPromptIds, setSavedPromptIds] = useState<Record<string, boolean>>({});

  const presetIdeas = [
    'Cyberpunk alleyway in heavy rain with neon reflections',
    'Minimalist frosted perfume bottle on travertine slab in dawn light',
    'Hyper-realistic biological alien flora glowing in deep ocean abyss',
    'Futuristic electric sports car parked in Brutalist architectural pavilion',
  ];

  const engineOptions = [
    { id: 'Midjourney v6.1', label: 'Midjourney v6.1' },
    { id: 'FLUX.1 Dev', label: 'FLUX.1 Dev' },
    { id: 'DALL-E 3', label: 'DALL-E 3' },
    { id: 'LLM System Prompt', label: 'LLM System Prompt' },
    { id: 'UI/UX Visual Concept', label: 'UI/UX Concept' },
  ];

  const aspectRatios = [
    { label: '16:9', desc: 'Landscape / Cinematic' },
    { label: '1:1', desc: 'Square / Social' },
    { label: '9:16', desc: 'Story / Mobile' },
    { label: '4:5', desc: 'Portrait / Feed' },
    { label: '21:9', desc: 'Ultrawide' },
  ];

  const stylePresets = [
    'Cinematic 35mm Film',
    'Hyper-Detailed Editorial Fashion',
    'Clean Isometric 3D Render',
    'Dark Fantasy Oil Painting',
    'Futuristic Industrial Blueprint',
    'Minimalist Product Advertising',
  ];

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!concept.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const data = await generatePrompts({
        concept: concept.trim(),
        toolType,
        style,
        aspectRatio,
        mood,
        lighting,
        camera,
      });

      setResult(data);

      // Auto save best prompt to history
      if (data.prompts && data.prompts.length > 0) {
        onSaveToHistory({
          type: 'prompt',
          title: data.prompts[0].title || concept.slice(0, 40),
          snippet: data.prompts[0].mainPrompt,
          fullData: data,
          engine: toolType,
        });
      }
    } catch (err: any) {
      if (err instanceof ApiError) {
        setError({ message: err.message, code: err.code });
      } else {
        setError({ message: err?.message || 'Failed to generate prompts' });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleManualSave = (prompt: GeneratedPrompt) => {
    onSaveToHistory({
      type: 'prompt',
      title: prompt.title || concept.slice(0, 40),
      snippet: prompt.mainPrompt,
      fullData: { concept, prompt, toolType },
      engine: toolType,
    });
    if (onSaveToLibrary) {
      onSaveToLibrary({
        type: 'prompt',
        title: prompt.title || concept.slice(0, 40),
        content: prompt.mainPrompt,
        negativePrompt: prompt.negativePrompt,
        parameters: prompt.technicalParameters,
        category: 'Image Generation',
        tags: [toolType, aspectRatio, style].filter(Boolean),
      });
    }
    setSavedPromptIds((prev) => ({ ...prev, [prompt.id]: true }));
    setTimeout(() => {
      setSavedPromptIds((prev) => ({ ...prev, [prompt.id]: false }));
    }, 2000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-fadeIn">
      {/* Missing API Key banner if needed */}
      {!serverStatus?.hasApiKey && (
        <ApiKeyBanner onOpenSettings={onOpenSettings} />
      )}

      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-cyan-400 text-xs font-mono font-medium mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>PROMPT SYNTHESIS ENGINE</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
          AI Prompt Generator
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Craft multi-tier, parameter-tuned prompts engineered specifically for Midjourney, FLUX, and creative LLMs.
        </p>
      </div>

      {/* Main Input Form */}
      <form onSubmit={handleGenerate} className="p-4 sm:p-6 rounded-2xl bg-[#0B132B]/90 border border-slate-800 shadow-xl space-y-4">
        {/* Concept Textarea */}
        <div>
          <label htmlFor="prompt-concept" className="block text-xs font-bold text-slate-200 mb-2">
            What do you want to create? <span className="text-cyan-400">*</span>
          </label>
          <textarea
            id="prompt-concept"
            rows={3}
            value={concept}
            onChange={(e) => setConcept(e.target.value)}
            placeholder="e.g. A solitary astronaut standing on obsidian sands under a violet binary star system, atmospheric dust, cinematic scale..."
            className="w-full px-4 py-3 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 text-slate-100 placeholder:text-slate-500 text-xs sm:text-sm resize-none outline-none transition-all"
          />
        </div>

        {/* Quick Inspiration Chips */}
        <div>
          <span className="text-[11px] font-mono text-slate-400 block mb-2">
            Quick Inceptions (tap to fill):
          </span>
          <div className="flex flex-wrap gap-1.5">
            {presetIdeas.map((idea, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setConcept(idea)}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/30 text-[11px] text-slate-300 hover:text-white transition-all text-left truncate max-w-full"
              >
                {idea}
              </button>
            ))}
          </div>
        </div>

        {/* Target Engine Selector */}
        <div>
          <label className="block text-xs font-bold text-slate-200 mb-2">
            Target Generator Engine
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {engineOptions.map((eng) => (
              <button
                key={eng.id}
                type="button"
                onClick={() => setToolType(eng.id)}
                className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 active:scale-95 flex items-center justify-center text-center ${
                  toolType === eng.id
                    ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-500/50 shadow-sm'
                    : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {eng.label}
              </button>
            ))}
          </div>
        </div>

        {/* Aspect Ratio Selector */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Ratio className="w-3.5 h-3.5 text-cyan-400" />
              <span>Aspect Ratio</span>
            </label>
            <span className="text-[11px] font-mono text-cyan-400 font-semibold">{aspectRatio}</span>
          </div>
          <div className="grid grid-cols-5 gap-2">
            {aspectRatios.map((ar) => (
              <button
                key={ar.label}
                type="button"
                onClick={() => setAspectRatio(ar.label)}
                className={`min-h-[44px] py-2 px-1 rounded-xl flex flex-col items-center justify-center transition-all active:scale-95 ${
                  aspectRatio === ar.label
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                    : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 border border-slate-800'
                }`}
              >
                <span className="text-xs font-bold font-mono">{ar.label}</span>
                <span className="text-[9px] text-slate-400 truncate hidden xs:block">{ar.desc.split(' ')[0]}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Advanced Styling Drawer Toggle */}
        <div className="pt-2">
          <button
            type="button"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 py-1"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>{showAdvanced ? 'Hide Optical Parameters' : 'Fine-Tune Lighting, Camera & Lens Parameters'}</span>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
          </button>

          {showAdvanced && (
            <div className="mt-3 p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3.5 animate-in slide-in-from-top-2 duration-150">
              {/* Style preset dropdown */}
              <div>
                <label className="block text-[11px] font-mono text-slate-300 mb-1.5">
                  Artistic &amp; Film Preset
                </label>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 outline-none"
                >
                  {stylePresets.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              {/* Lighting */}
              <div>
                <label className="block text-[11px] font-mono text-slate-300 mb-1.5 flex items-center gap-1">
                  <Sun className="w-3 h-3 text-amber-400" />
                  <span>Lighting Architecture</span>
                </label>
                <input
                  type="text"
                  value={lighting}
                  onChange={(e) => setLighting(e.target.value)}
                  placeholder="e.g. Volumetric rim light with neon rim glow"
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 outline-none"
                />
              </div>

              {/* Camera & Lens */}
              <div>
                <label className="block text-[11px] font-mono text-slate-300 mb-1.5 flex items-center gap-1">
                  <Camera className="w-3 h-3 text-cyan-400" />
                  <span>Camera, Lens &amp; Framing</span>
                </label>
                <input
                  type="text"
                  value={camera}
                  onChange={(e) => setCamera(e.target.value)}
                  placeholder="e.g. 35mm anamorphic prime lens, f/1.8 shallow depth of field"
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200 outline-none"
                />
              </div>
            </div>
          )}
        </div>

        {/* Submit Action CTA */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={loading || !concept.trim()}
            className="w-full min-h-[48px] px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-slate-950 font-bold text-sm tracking-wide shadow-lg glow-cyan active:scale-98 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                <span>Synthesizing Studio Prompts...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-slate-950" />
                <span>Generate Master Prompts (3 Variations)</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Loading State */}
      {loading && (
        <LoadingSkeleton
          title="MOSSIO Engine is composing your prompts..."
          subtitle="Calculating token weights, negative parameters, and camera metadata"
          cardsCount={3}
        />
      )}

      {/* Error State */}
      {error && !loading && (
        <ErrorCard
          message={error.message}
          code={error.code}
          onRetry={handleGenerate}
          onOpenSettings={onOpenSettings}
        />
      )}

      {/* Results Display */}
      {result && !loading && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Generated Prompt Suite</span>
            </h2>
            <span className="text-[11px] font-mono text-cyan-400">
              Engine: {toolType}
            </span>
          </div>

          {result.summary && (
            <div className="p-3.5 rounded-xl bg-cyan-950/20 border border-cyan-500/20 text-xs text-cyan-200 leading-relaxed">
              <span className="font-semibold text-cyan-300">Creative Direction: </span>
              {result.summary}
            </div>
          )}

          <div className="space-y-4">
            {result.prompts.map((p, idx) => {
              const isSaved = Boolean(savedPromptIds[p.id]);

              return (
                <div
                  key={p.id || idx}
                  className="rounded-2xl bg-[#0B132B] border border-slate-800 hover:border-cyan-500/40 transition-all p-4 sm:p-5 shadow-lg space-y-3"
                >
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300">
                          {p.variantName || `Variation ${idx + 1}`}
                        </span>
                        <h3 className="text-sm font-bold text-white">{p.title}</h3>
                      </div>
                      {p.whyItWorks && (
                        <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                          {p.whyItWorks}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleManualSave(p)}
                        className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                          isSaved
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : 'bg-slate-800/80 hover:bg-slate-750 text-slate-300 border border-slate-700'
                        }`}
                      >
                        {isSaved ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <BookmarkCheck className="w-3.5 h-3.5" />}
                        <span className="hidden xs:inline">{isSaved ? 'Saved' : 'Save'}</span>
                      </button>

                      <CopyButton
                        text={`${p.mainPrompt}${p.technicalParameters ? ` ${p.technicalParameters}` : ''}`}
                        label="Copy Prompt"
                        className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
                      />
                    </div>
                  </div>

                  {/* Main Prompt Text Container */}
                  <div className="relative p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 font-mono text-xs text-slate-200 leading-relaxed break-words select-all">
                    {p.mainPrompt}
                  </div>

                  {/* Technical Parameters & Negative Prompts */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {p.technicalParameters && (
                      <div className="p-2.5 rounded-lg bg-slate-900/70 border border-slate-800/70 flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <span className="text-[10px] font-mono text-slate-400 block">Parameters</span>
                          <span className="font-mono text-[11px] text-cyan-300 truncate block">
                            {p.technicalParameters}
                          </span>
                        </div>
                        <CopyButton text={p.technicalParameters} iconOnly className="min-h-[36px] min-w-[36px]" />
                      </div>
                    )}

                    {p.negativePrompt && (
                      <div className="p-2.5 rounded-lg bg-slate-900/70 border border-slate-800/70 flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <span className="text-[10px] font-mono text-slate-400 block">Negative Prompt</span>
                          <span className="font-mono text-[11px] text-rose-300 truncate block">
                            {p.negativePrompt}
                          </span>
                        </div>
                        <CopyButton text={p.negativePrompt} iconOnly className="min-h-[36px] min-w-[36px]" />
                      </div>
                    )}
                  </div>

                  {/* Tags */}
                  {p.tags && p.tags.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5 pt-1">
                      <Tag className="w-3 h-3 text-slate-400" />
                      {p.tags.map((tag, tIdx) => (
                        <span
                          key={tIdx}
                          className="text-[10px] font-mono text-slate-400 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
