import { useState } from 'react';
import {
  History,
  Trash2,
  Download,
  Search,
  Sparkles,
  Wand2,
  Lightbulb,
  MessageSquare,
  Clock,
  Check,
  AlertCircle,
  X,
} from 'lucide-react';
import { HistoryItem, HistoryItemType } from '../../types';
import { CopyButton } from '../common/CopyButton';
import { EmptyState } from '../common/EmptyState';

interface HistoryViewProps {
  history: HistoryItem[];
  onRemoveItem: (id: string) => void;
  onClearHistory: () => void;
  onExportJSON: () => void;
  onSelectTab: (tab: any) => void;
}

export function HistoryView({
  history,
  onRemoveItem,
  onClearHistory,
  onExportJSON,
  onSelectTab,
}: HistoryViewProps) {
  const [filterType, setFilterType] = useState<HistoryItemType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showClearModal, setShowClearModal] = useState(false);

  const filteredHistory = history.filter((item) => {
    const matchesType = filterType === 'all' || item.type === filterType;
    const matchesSearch =
      !searchQuery.trim() ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.snippet.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  const getIcon = (type: HistoryItemType) => {
    switch (type) {
      case 'prompt':
        return <Sparkles className="w-3.5 h-3.5 text-cyan-400" />;
      case 'improvement':
        return <Wand2 className="w-3.5 h-3.5 text-violet-400" />;
      case 'idea':
        return <Lightbulb className="w-3.5 h-3.5 text-amber-400" />;
      case 'chat':
        return <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />;
    }
  };

  const formatTime = (ts: number) => {
    const diff = Math.floor((Date.now() - ts) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-violet-400 text-xs font-mono font-medium mb-1">
            <History className="w-3.5 h-3.5" />
            <span>STUDIO ARCHIVE</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
            Creative Generation History
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Review, copy, or export prompts and creative briefs generated in this workspace.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            type="button"
            onClick={onExportJSON}
            disabled={history.length === 0}
            className="min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700/80 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-40"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export JSON</span>
          </button>

          <button
            type="button"
            onClick={() => setShowClearModal(true)}
            disabled={history.length === 0}
            className="min-h-[40px] px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-40"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
            <span>Clear Archive</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-[#0B132B]/90 border border-slate-800 space-y-3">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search prompts, keywords, concepts..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-cyan-500 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {(['all', 'prompt', 'improvement', 'idea', 'chat'] as const).map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setFilterType(tab)}
              className={`min-h-[38px] px-3 py-1.5 rounded-lg text-xs font-semibold transition-all active:scale-95 ${
                filterType === tab
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {tab === 'all' && `All (${history.length})`}
              {tab === 'prompt' && 'Prompts'}
              {tab === 'improvement' && 'Rewrites'}
              {tab === 'idea' && 'Ideas'}
              {tab === 'chat' && 'Chats'}
            </button>
          ))}
        </div>
      </div>

      {/* History Items List */}
      {filteredHistory.length === 0 ? (
        <EmptyState
          icon={History}
          title={searchQuery ? 'No matching records found' : 'Your Creative Archive is Empty'}
          description={
            searchQuery
              ? 'Try adjusting your search query or switching categories.'
              : 'Synthesized prompts, rewritten drafts, and brainstormed campaigns will appear here automatically.'
          }
          actionLabel="Open Prompt Generator"
          onAction={() => onSelectTab('generator')}
        />
      ) : (
        <div className="space-y-3">
          {filteredHistory.map((item) => (
            <div
              key={item.id}
              className="p-4 sm:p-5 rounded-2xl bg-[#0B132B] border border-slate-800 hover:border-slate-700/80 transition-all flex flex-col sm:flex-row sm:items-start justify-between gap-3 group"
            >
              <div className="min-w-0 flex-1 space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-300">
                    {getIcon(item.type)}
                    <span className="capitalize">{item.type}</span>
                  </div>

                  {item.engine && (
                    <span className="text-[10px] font-mono text-cyan-400">
                      {item.engine}
                    </span>
                  )}

                  <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{formatTime(item.timestamp)}</span>
                  </span>
                </div>

                <h3 className="text-sm font-bold text-white group-hover:text-cyan-200 transition-colors">
                  {item.title}
                </h3>

                <p className="text-xs text-slate-300 font-mono leading-relaxed line-clamp-3 select-all bg-slate-950/60 p-2.5 rounded-xl border border-slate-900">
                  {item.snippet}
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-start pt-2 sm:pt-0">
                <CopyButton text={item.snippet} label="Copy" />
                <button
                  type="button"
                  onClick={() => onRemoveItem(item.id)}
                  title="Remove from history"
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-900 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-800 hover:border-rose-500/30 transition-all active:scale-95"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Confirmation Modal for Clear History */}
      {showClearModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setShowClearModal(false)}
          />
          <div className="relative w-full max-w-sm rounded-2xl bg-[#0B132B] border border-rose-500/40 p-6 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertCircle className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-base font-bold text-white">Clear All Studio History?</h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                This will permanently delete all {history.length} saved prompts and idea briefs from this browser's storage. You can export a JSON backup first.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowClearModal(false)}
                className="flex-1 min-h-[44px] rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearHistory();
                  setShowClearModal(false);
                }}
                className="flex-1 min-h-[44px] rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-md active:scale-95"
              >
                Yes, Clear All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
