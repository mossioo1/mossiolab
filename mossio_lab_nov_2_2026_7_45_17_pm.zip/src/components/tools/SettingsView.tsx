import { useState } from 'react';
import {
  Settings,
  Server,
  KeyRound,
  Smartphone,
  Palette,
  Database,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  ShieldCheck,
  Zap,
  Activity,
  Check,
  XCircle,
} from 'lucide-react';
import { ServerStatus, ConnectionTestResult } from '../../types';
import { fetchServerStatus, testConnection } from '../../services/api';

interface SettingsViewProps {
  serverStatus: ServerStatus | null;
  onRefreshStatus: () => void;
  historyCount: number;
  onExportJSON: () => void;
  onClearHistory: () => void;
}

export function SettingsView({
  serverStatus,
  onRefreshStatus,
  historyCount,
  onExportJSON,
  onClearHistory,
}: SettingsViewProps) {
  const [checking, setChecking] = useState(false);
  const [testResult, setTestResult] = useState<ConnectionTestResult | null>(null);
  const [activeThemeAccent, setActiveThemeAccent] = useState<'cyan' | 'violet' | 'emerald'>('cyan');

  const handleTestConnection = async () => {
    setChecking(true);
    try {
      const res = await testConnection();
      setTestResult(res);
      onRefreshStatus();
    } catch (err: any) {
      console.error('Test connection error:', err);
      setTestResult({
        success: false,
        configured: Boolean(serverStatus?.hasApiKey),
        message: err?.message || 'Network request to server failed.',
        model: 'gemini-3.8-flash',
        testedAt: new Date().toISOString(),
      });
    } finally {
      setChecking(false);
    }
  };

  const isOnline = serverStatus?.hasApiKey;

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fadeIn">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-cyan-400 text-xs font-mono font-medium mb-1">
          <Settings className="w-3.5 h-3.5" />
          <span>SYSTEM &amp; CONFIGURATION</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
          Settings &amp; Model Diagnostics
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Verify your server-side Gemini Flash connection with live telemetry, manage API keys, and review mobile testing guidance.
        </p>
      </div>

      {/* Server & AI Model Status Card */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#0B132B] border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              testResult?.success
                ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-400'
                : testResult && !testResult.success
                ? 'bg-amber-500/15 border border-amber-500/30 text-amber-400'
                : isOnline
                ? 'bg-cyan-500/15 border border-cyan-500/30 text-cyan-400'
                : 'bg-amber-500/15 border border-amber-500/30 text-amber-400'
            }`}>
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                Server-Side AI Engine Status
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded uppercase font-bold ${
                    testResult?.success
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : testResult && !testResult.success
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : isOnline
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {testResult?.success
                    ? 'VERIFIED & LIVE'
                    : testResult && !testResult.success
                    ? 'TEST FAILED'
                    : isOnline
                    ? 'KEY DETECTED (UNVERIFIED)'
                    : 'KEY NOT DETECTED'}
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Active Model: <span className="text-cyan-300 font-mono font-medium">{serverStatus?.model || 'gemini-3.1-flash-lite'}</span> (fallback: <span className="text-slate-400 font-mono">gemini-3.8-flash</span>)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleTestConnection}
            disabled={checking}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs tracking-wide flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 shrink-0 shadow-md glow-cyan"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${checking ? 'animate-spin' : ''}`} />
            <span>{checking ? 'Testing Live Connection...' : 'Ping & Test Connection'}</span>
          </button>
        </div>

        {/* Live Test Diagnostic Output Card */}
        {testResult && (
          <div
            className={`p-4 rounded-xl border text-xs space-y-2 animate-in fade-in duration-200 ${
              testResult.success
                ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200'
                : 'bg-amber-950/20 border-amber-500/40 text-amber-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-semibold">
                {testResult.success ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Real-Time Connection Test Passed</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Connection Test Diagnostic:</span>
                  </>
                )}
              </div>
              {testResult.latencyMs !== undefined && (
                <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-black/40 text-slate-300">
                  Latency: {testResult.latencyMs}ms
                </span>
              )}
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed break-words">
              {testResult.message}
            </p>

            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-1 border-t border-slate-800/60">
              <span>Model: {testResult.model}</span>
              <span>Tested: {new Date(testResult.testedAt).toLocaleTimeString()}</span>
            </div>
          </div>
        )}

        {/* Security & Architecture Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200 mb-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Zero-Key Exposure</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              API keys are never transmitted to browser bundles. All requests run server-to-server.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200 mb-1">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>Live Ping Verifier</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Ping button performs an actual request to Gemini API and measures latency.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200 mb-1">
              <KeyRound className="w-4 h-4 text-amber-400" />
              <span>Platform Secrets</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Uses Google AI Studio's secure Secrets manager via GEMINI_API_KEY.
            </p>
          </div>
        </div>
      </div>

      {/* Step-by-Step Mobile Secrets Guide */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#0B132B] border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">
              Where to Add GEMINI_API_KEY in Google AI Studio on Mobile
            </h3>
            <p className="text-xs text-slate-400">
              Exact instructions for configuring your secret from an Android browser
            </p>
          </div>
        </div>

        <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
          <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1.5">
            <div className="font-semibold text-amber-300 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[11px] font-bold font-mono">
                1
              </span>
              <span>Find the Secrets Panel in AI Studio</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed pl-7">
              In your mobile browser on Google AI Studio, look at the top header or hamburger navigation drawer for the <strong className="text-white">Secrets</strong> tab (often shown as a Key icon 🔑 or listed under project settings).
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1.5">
            <div className="font-semibold text-amber-300 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[11px] font-bold font-mono">
                2
              </span>
              <span>Define the Secret Name</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed pl-7">
              Tap <strong className="text-white">"Add Secret"</strong> (or "New Secret"). In the Secret Name field, type exactly:
              <code className="mx-1 px-2 py-0.5 rounded bg-slate-950 font-mono text-cyan-300 font-bold border border-slate-800">
                GEMINI_API_KEY
              </code>
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1.5">
            <div className="font-semibold text-amber-300 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[11px] font-bold font-mono">
                3
              </span>
              <span>Paste Your Gemini API Key &amp; Save</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed pl-7">
              Paste your Google Gemini API key into the Secret Value field and tap Save. AI Studio automatically injects this secret into <code className="font-mono text-cyan-300">process.env.GEMINI_API_KEY</code> on your cloud backend.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1.5">
            <div className="font-semibold text-amber-300 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[11px] font-bold font-mono">
                4
              </span>
              <span>Verify with "Ping &amp; Test Connection"</span>
            </div>
            <p className="text-slate-400 text-[11px] leading-relaxed pl-7">
              Return to MOSSIO LAB Settings and tap <strong className="text-cyan-300">"Ping &amp; Test Connection"</strong> above. The server will execute an active round-trip handshake with Google's servers and display your actual round-trip latency.
            </p>
          </div>
        </div>
      </div>

      {/* Android Mobile Development & Testing Guide */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#0B132B] border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">
              Android Phone Development &amp; Preview Tips
            </h3>
            <p className="text-xs text-slate-400">
              Tested for touch-first smartphone workflows and mobile Chrome
            </p>
          </div>
        </div>

        <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
          <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
            <div className="font-semibold text-cyan-300">1. Instant Mobile Previewing</div>
            <p className="text-slate-400 text-[11px]">
              Open the development or shared preview URL directly in your Android phone browser (Chrome, Samsung Internet, or Firefox). The layout automatically switches to mobile ergonomics with bottom navigation and drawer menus.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
            <div className="font-semibold text-cyan-300">2. Install as App (Home Screen Shortcut)</div>
            <p className="text-slate-400 text-[11px]">
              Tap the 3 dots menu in Android Chrome &gt; tap <strong className="text-slate-200">"Add to Home screen"</strong> or <strong className="text-slate-200">"Install app"</strong>. MOSSIO LAB includes standalone viewport-fit meta tags so it will open in full-screen immersion like a native app.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
            <div className="font-semibold text-cyan-300">3. Thumb-Zone Controls &amp; 1-Tap Copying</div>
            <p className="text-slate-400 text-[11px]">
              All key action buttons meet Android Material touch target minimums (&ge; 44px). The Copy-to-Clipboard buttons use modern Clipboard APIs with mobile fallbacks for rapid pasting into Midjourney or Discord.
            </p>
          </div>
        </div>
      </div>

      {/* Theme Accent Preferences */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#0B132B] border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-violet-500/15 border border-violet-500/30 flex items-center justify-center text-violet-400">
            <Palette className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Studio Neon Visual Accent</h3>
            <p className="text-xs text-slate-400">
              Customize primary highlights and glow profiles
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <button
            type="button"
            onClick={() => setActiveThemeAccent('cyan')}
            className={`p-3 rounded-xl border text-left transition-all active:scale-95 ${
              activeThemeAccent === 'cyan'
                ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.25)]'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            <div className="w-4 h-4 rounded-full bg-cyan-400 mb-2 shadow-[0_0_8px_#22d3ee]" />
            <div className="text-xs font-bold text-white">Electric Cyan</div>
            <div className="text-[10px] text-slate-400">Default Studio</div>
          </button>

          <button
            type="button"
            onClick={() => setActiveThemeAccent('violet')}
            className={`p-3 rounded-xl border text-left transition-all active:scale-95 ${
              activeThemeAccent === 'violet'
                ? 'bg-violet-500/20 border-violet-500 text-violet-300 shadow-[0_0_15px_rgba(168,85,247,0.25)]'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            <div className="w-4 h-4 rounded-full bg-violet-400 mb-2 shadow-[0_0_8px_#c084fc]" />
            <div className="text-xs font-bold text-white">Cyber Violet</div>
            <div className="text-[10px] text-slate-400">High Contrast</div>
          </button>

          <button
            type="button"
            onClick={() => setActiveThemeAccent('emerald')}
            className={`p-3 rounded-xl border text-left transition-all active:scale-95 ${
              activeThemeAccent === 'emerald'
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.25)]'
                : 'bg-slate-900 border-slate-800 text-slate-400'
            }`}
          >
            <div className="w-4 h-4 rounded-full bg-emerald-400 mb-2 shadow-[0_0_8px_#34d399]" />
            <div className="text-xs font-bold text-white">Matrix Pulse</div>
            <div className="text-[10px] text-slate-400">Tactical Green</div>
          </button>
        </div>
      </div>

      {/* Storage and Export Management */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#0B132B] border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">Workspace Storage &amp; Backup</h3>
            <p className="text-xs text-slate-400">
              Current local storage: {historyCount} items recorded
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <button
            type="button"
            onClick={onExportJSON}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 transition-all active:scale-95"
          >
            <span>Download Creative Backup (.json)</span>
          </button>

          <button
            type="button"
            onClick={onClearHistory}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center gap-2 transition-all active:scale-95"
          >
            <span>Reset Local Archive</span>
          </button>
        </div>
      </div>
    </div>
  );
}
