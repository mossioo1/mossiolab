import { useState } from 'react';
import {
  Lightbulb,
  Sparkles,
  BookmarkCheck,
  Check,
  Tag,
  RefreshCw,
  FolderPlus,
  Star,
  Film,
  Image,
  BookOpen,
  Briefcase,
  Building2,
  Gamepad2,
  Compass,
} from 'lucide-react';
import { generateCreativeIdeas, ApiError } from '../../services/api';
import { CreativeIdeasResult, CreativeConcept, ServerStatus, LibraryItem } from '../../types';
import { CopyButton } from '../common/CopyButton';
import { LoadingSkeleton } from '../common/LoadingSkeleton';
import { ErrorCard } from '../common/ErrorCard';
import { EmptyState } from '../common/EmptyState';
import { ApiKeyBanner } from '../common/ApiKeyBanner';

interface IdeaGeneratorProps {
  onSaveToHistory: (item: {
    type: 'idea';
    title: string;
    snippet: string;
    fullData: any;
    engine?: string;
  }) => void;
  onSaveToLibrary?: (item: {
    type: 'idea';
    title: string;
    content: string;
    category?: string;
    tags?: string[];
    isFavorite?: boolean;
  }) => { item: LibraryItem; wasDuplicate: boolean };
  onOpenSettings?: () => void;
  serverStatus: ServerStatus | null;
}

export function IdeaGenerator({
  onSaveToHistory,
  onSaveToLibrary,
  onOpenSettings,
  serverStatus,
}: IdeaGeneratorProps) {
  const [topic, setTopic] = useState('');
  const [category, setCategory] = useState('image');
  const [tone, setTone] = useState('Provocative, high-end, cyberpunk luxury');
  const [targetAudience, setTargetAudience] = useState('Creative directors, founders & tastemakers');
  const [ideaCount, setIdeaCount] = useState<number>(4);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<{ message: string; code?: string } | null>(null);
  const [result, setResult] = useState<CreativeIdeasResult | null>(null);
  const [favorites, setFavorites] = useState<Record<string, boolean>>({});
  const [librarySavedIds, setLibrarySavedIds] = useState<Record<string, string>>({});

  const categories = [
    { id: 'image', label: 'Image', icon: Image, desc: 'Key visuals & art' },
    { id: 'video', label: 'Video', icon: Film, desc: 'Cinematic spots' },
    { id: 'storytelling', label: 'Storytelling', icon: BookOpen, desc: 'Worldbuilding & arcs' },
    { id: 'branding', label: 'Branding', icon: Briefcase, desc: 'Identity & hooks' },
    { id: 'architecture', label: 'Architecture', icon: Building2, desc: 'Spatial & interiors' },
    { id: 'game concepts', label: 'Game Concepts', icon: Gamepad2, desc: 'Mechanics & lore' },
    { id: 'general creativity', label: 'General', icon: Compass, desc: 'Multi-disciplinary' },
  ];

  const sampleBriefs = [
    'An autonomous electric motorcycle brand launch in Tokyo',
    'A generative AI spatial audio workstation for music producers',
    'A sustainable architectural sanctuary built into Icelandic basalt cliffs',
    'A dystopian cyberpunk roguelike game set in a vertical megacity',
  ];

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!topic.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const data = await generateCreativeIdeas({
        topic: topic.trim(),
        category,
        tone,
        targetAudience,
        count: ideaCount,
      });

      setResult(data);

      // Auto save top concept to history
      if (data.concepts && data.concepts.length > 0) {
        onSaveToHistory({
          type: 'idea',
          title: data.campaignTitle || data.concepts[0].title,
          snippet: `${data.concepts[0].title}: "${data.concepts[0].hook}" — ${data.concepts[0].narrative.slice(0, 120)}...`,
          fullData: data,
          engine: `Idea Lab (${category})`,
        });
      }
    } catch (err: any) {
      if (err instanceof ApiError) {
        setError({ message: err.message, code: err.code });
      } else {
        setError({ message: err?.message || 'Failed to generate ideas' });
      }
    } finally {
      setLoading(false);
    }
  };

  const toggleFavoriteConcept = (id: string) => {
    setFavorites((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleSaveConceptToLibrary = (concept: CreativeConcept) => {
    if (!onSaveToLibrary) return;

    const res = onSaveToLibrary({
      type: 'idea',
      title: concept.title,
      content: `Hook: "${concept.hook}"\n\nNarrative: ${concept.narrative}\n\nVisual Direction: ${concept.visualDirection}\n\nRecommended Prompt:\n${concept.recommendedPrompt}`,
      category,
      tags: [category, 'Idea', ...((concept.deliverables as string[]) || [])],
      isFavorite: Boolean(favorites[concept.id]),
    });

    setLibrarySavedIds((prev) => ({
      ...prev,
      [concept.id]: res.wasDuplicate ? 'Already in Library' : 'Saved!',
    }));

    setTimeout(() => {
      setLibrarySavedIds((prev) => {
        const copy = { ...prev };
        delete copy[concept.id];
        return copy;
      });
    }, 2500);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-fadeIn">
      {/* Missing API Key banner if needed */}
      {!serverStatus?.hasApiKey && (
        <ApiKeyBanner onOpenSettings={onOpenSettings} />
      )}

      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-medium mb-1">
          <Lightbulb className="w-3.5 h-3.5" />
          <span>CREATIVE INCUBATOR &amp; STRATEGY</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
          Creative Idea Generator
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Synthesize high-concept campaigns, game worlds, branding hooks, and spatial architecture with ready-to-run AI prompts.
        </p>
      </div>

      {/* Main Input Form */}
      <form onSubmit={handleGenerate} className="p-4 sm:p-6 rounded-2xl bg-[#0B132B]/90 border border-slate-800 shadow-xl space-y-4">
        {/* Topic textarea */}
        <div>
          <label htmlFor="idea-topic" className="block text-xs font-bold text-slate-200 mb-2">
            Project Topic, Product or Creative Challenge: <span className="text-amber-400">*</span>
          </label>
          <textarea
            id="idea-topic"
            rows={3}
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g. An autonomous electric motorcycle brand launch in Tokyo... or: A psychological sci-fi game about memory harvesting"
            className="w-full px-4 py-3 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-slate-100 placeholder:text-slate-500 text-xs sm:text-sm resize-none outline-none transition-all leading-relaxed"
          />
        </div>

        {/* Quick Sample Chips */}
        <div>
          <span className="text-[11px] font-mono text-slate-400 block mb-1.5">
            Explore starter project briefs:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {sampleBriefs.map((brief, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setTopic(brief)}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 hover:text-amber-300 transition-all text-left truncate max-w-full"
              >
                {brief}
              </button>
            ))}
          </div>
        </div>

        {/* Categories Grid (image, video, storytelling, branding, architecture, game concepts, general creativity) */}
        <div>
          <label className="block text-xs font-bold text-slate-200 mb-2">
            Creative Domain Category
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
            {categories.map((c) => {
              const Icon = c.icon;
              const isSelected = category === c.id;

              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCategory(c.id)}
                  className={`min-h-[52px] p-2 rounded-xl text-center flex flex-col items-center justify-center transition-all active:scale-95 border ${
                    isSelected
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/60 shadow-sm'
                      : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 border-slate-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 mb-1 ${isSelected ? 'text-amber-400' : 'text-slate-400'}`} />
                  <span className="text-[11px] font-semibold truncate leading-none">{c.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tone, Audience, and Count Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[11px] font-mono text-slate-300 mb-1">
              Desired Tone &amp; Vibe
            </label>
            <input
              type="text"
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              placeholder="e.g. Provocative, luxury minimalism, cinematic"
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-200 outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono text-slate-300 mb-1">
              Target Audience
            </label>
            <input
              type="text"
              value={targetAudience}
              onChange={(e) => setTargetAudience(e.target.value)}
              placeholder="e.g. Creative directors, founders, gamers"
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-200 outline-none"
            />
          </div>

          {/* Number of ideas selector */}
          <div>
            <label className="block text-[11px] font-mono text-slate-300 mb-1">
              Number of Concepts
            </label>
            <div className="grid grid-cols-4 gap-1.5 h-[38px]">
              {[2, 4, 6, 8].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setIdeaCount(num)}
                  className={`rounded-xl text-xs font-bold transition-all active:scale-95 border ${
                    ideaCount === num
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/60'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {num}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={loading || !topic.trim()}
            className="w-full min-h-[48px] px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-violet-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-sm tracking-wide shadow-lg active:scale-98 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-slate-950" />
                <span>Synthesizing {ideaCount} Creative Concepts...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-slate-950" />
                <span>Generate {ideaCount} Concepts in {category.toUpperCase()}</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Loading state */}
      {loading && (
        <LoadingSkeleton
          title="Architecting Studio Creative Concepts..."
          subtitle={`Synthesizing ${ideaCount} concepts for ${category} with emotional hooks, narratives, and AI visualization prompts`}
          cardsCount={Math.min(ideaCount, 4)}
        />
      )}

      {/* Error state */}
      {error && !loading && (
        <ErrorCard
          message={error.message}
          code={error.code}
          onRetry={handleGenerate}
          onOpenSettings={onOpenSettings}
        />
      )}

      {/* Empty state when no ideas generated yet */}
      {!result && !loading && !error && (
        <EmptyState
          icon={Lightbulb}
          title="Creative Canvas Ready"
          description="Enter a product, story concept, or campaign topic above to incubate fresh, non-generic creative angles."
          actionLabel="Try Motorcycle Brief"
          onAction={() => {
            setTopic('An autonomous electric motorcycle brand launch in Tokyo');
            setCategory('branding');
          }}
          accentColor="amber"
        />
      )}

      {/* Results View */}
      {result && !loading && (
        <div className="space-y-5 animate-fadeIn">
          {/* Overarching Thesis Banner */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/30 via-slate-900 to-purple-950/30 border border-amber-500/30 space-y-1.5 shadow-xl">
            <span className="text-[10px] font-mono text-amber-400 font-bold uppercase tracking-wider block">
              OVERARCHING STRATEGIC THESIS
            </span>
            <h2 className="text-lg font-bold text-white">{result.campaignTitle}</h2>
            <p className="text-xs text-slate-300 leading-relaxed">{result.coreThesis}</p>
          </div>

          {/* Concepts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {result.concepts.map((concept, idx) => {
              const isFav = Boolean(favorites[concept.id]);
              const saveStatus = librarySavedIds[concept.id];

              return (
                <div
                  key={concept.id || idx}
                  className="p-5 rounded-2xl bg-[#0B132B] border border-slate-800 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-4 shadow-lg"
                >
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span className="text-[10px] font-mono font-bold text-amber-400 uppercase">
                          CONCEPT 0{idx + 1} · {category}
                        </span>
                        <h3 className="text-base font-bold text-white mt-0.5">{concept.title}</h3>
                      </div>

                      {/* Favorite & Save buttons */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => toggleFavoriteConcept(concept.id)}
                          title={isFav ? 'Remove favorite' : 'Add to favorites'}
                          className={`min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl border transition-all ${
                            isFav
                              ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                              : 'bg-slate-900 text-slate-400 hover:text-amber-300 border-slate-800'
                          }`}
                        >
                          <Star className={`w-4 h-4 ${isFav ? 'fill-amber-400' : ''}`} />
                        </button>

                        {onSaveToLibrary && (
                          <button
                            type="button"
                            onClick={() => handleSaveConceptToLibrary(concept)}
                            className="min-h-[38px] px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold flex items-center gap-1 transition-all active:scale-95"
                          >
                            <FolderPlus className="w-3.5 h-3.5 text-cyan-400" />
                            <span>{saveStatus || 'Save'}</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Hook Callout */}
                    <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-200 italic">
                      "{concept.hook}"
                    </div>

                    {/* Narrative */}
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {concept.narrative}
                    </p>

                    {/* Visual Staging Cues */}
                    {concept.visualDirection && (
                      <div className="text-xs text-slate-400 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                        <span className="text-cyan-400 font-semibold block text-[11px] mb-1">
                          Visual &amp; Sensory Staging:
                        </span>
                        <span className="leading-relaxed">{concept.visualDirection}</span>
                      </div>
                    )}
                  </div>

                  {/* Ready-to-run prompt container */}
                  {concept.recommendedPrompt && (
                    <div className="pt-3 border-t border-slate-800/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-cyan-400" />
                          <span>AI Visualization Prompt:</span>
                        </span>
                        <CopyButton text={concept.recommendedPrompt} label="Copy Prompt" />
                      </div>
                      <p className="p-2.5 rounded-lg bg-slate-950 font-mono text-[11px] text-slate-300 line-clamp-3 select-all leading-relaxed">
                        {concept.recommendedPrompt}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
