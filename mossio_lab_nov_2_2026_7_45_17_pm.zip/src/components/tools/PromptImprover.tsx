import { useState } from 'react';
import {
  Wand2,
  Sparkles,
  Layers,
  RefreshCw,
  BookmarkCheck,
  Check,
  Globe,
  Camera,
  Sun,
  Palette,
  Maximize2,
  Sliders,
  Shield,
  Copy,
  Lightbulb,
  CheckCircle2,
  FolderPlus,
} from 'lucide-react';
import { improvePrompt, ApiError } from '../../services/api';
import { PromptImprovementResult, ServerStatus, LibraryItem } from '../../types';
import { CopyButton } from '../common/CopyButton';
import { LoadingSkeleton } from '../common/LoadingSkeleton';
import { ErrorCard } from '../common/ErrorCard';
import { ApiKeyBanner } from '../common/ApiKeyBanner';

interface PromptImproverProps {
  onSaveToHistory: (item: {
    type: 'improvement';
    title: string;
    snippet: string;
    fullData: any;
    engine?: string;
  }) => void;
  onSaveToLibrary?: (item: {
    type: 'enhancement';
    title: string;
    content: string;
    negativePrompt?: string;
    category?: string;
    tags?: string[];
  }) => { item: LibraryItem; wasDuplicate: boolean };
  onOpenSettings?: () => void;
  serverStatus: ServerStatus | null;
}

export function PromptImprover({
  onSaveToHistory,
  onSaveToLibrary,
  onOpenSettings,
  serverStatus,
}: PromptImproverProps) {
  const [originalPrompt, setOriginalPrompt] = useState('');
  const [targetGoal, setTargetGoal] = useState('Photorealistic Realism');
  const [targetEngine, setTargetEngine] = useState('image');
  const [languageMode, setLanguageMode] = useState<'auto' | 'en' | 'fa'>('auto');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<{ message: string; code?: string } | null>(null);
  const [result, setResult] = useState<PromptImprovementResult | null>(null);
  const [savedToLibraryStatus, setSavedToLibraryStatus] = useState<string | null>(null);

  const samplePrompts = [
    { label: 'Perfume on stone', en: 'a luxury perfume bottle on a stone with nice light', fa: 'شیشه عطر لوکس روی سنگ با نور خوب' },
    { label: 'Cyberpunk street', en: 'futuristic city street with flying cars at night', fa: 'خیابان شهری آینده‌نگر با ماشین‌های پرنده در شب' },
    { label: 'Modern house in forest', en: 'modern minimalist concrete villa inside misty pine forest', fa: 'ویلای بتنی مدرن در جنگل کاج مه‌آلود با پنجره‌های بزرگ' },
    { label: 'Traditional Persian courtyard', en: 'luxurious Persian courtyard garden with turquoise tiled pond and morning sunlight', fa: 'حیاط سنتی ایرانی با حوض فیروزه‌ای و نور ملایم صبحگاهی' },
  ];

  const goals = [
    { id: 'Photorealistic Realism', label: 'Cinematic Realism', desc: 'Adds camera, focal length, volumetric light' },
    { id: 'Minimalist High-Concept', label: 'Minimalist Concept', desc: 'Focuses on negative space, texture & materiality' },
    { id: 'Concise & High Token Weight', label: 'High Token Density', desc: 'Eliminates filler words and boosts signal' },
    { id: 'Technical Specifications', label: 'Technical Spec', desc: 'Engine syntax, render engines & render tags' },
  ];

  const handleImprove = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!originalPrompt.trim()) return;

    setLoading(true);
    setError(null);
    setSavedToLibraryStatus(null);

    try {
      const data = await improvePrompt({
        originalPrompt: originalPrompt.trim(),
        targetGoal,
        targetEngine,
        language: languageMode,
      });

      setResult(data);

      // Auto save to history
      onSaveToHistory({
        type: 'improvement',
        title: originalPrompt.slice(0, 36) + '...',
        snippet: data.masterRewritten,
        fullData: data,
        engine: `Prompt Enhancer (${data.language === 'fa' ? 'Persian' : 'English'})`,
      });
    } catch (err: any) {
      if (err instanceof ApiError) {
        setError({ message: err.message, code: err.code });
      } else {
        setError({ message: err?.message || 'Failed to enhance prompt' });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSaveToLibraryClick = () => {
    if (!result || !onSaveToLibrary) return;

    const res = onSaveToLibrary({
      type: 'enhancement',
      title: result.original.slice(0, 40) + '...',
      content: result.masterRewritten,
      negativePrompt: result.negativePrompt,
      category: targetGoal,
      tags: [result.language === 'fa' ? 'Farsi' : 'English', targetGoal, 'Enhanced'],
    });

    if (res.wasDuplicate) {
      setSavedToLibraryStatus('Already in Library');
    } else {
      setSavedToLibraryStatus('Saved to Library!');
    }

    setTimeout(() => setSavedToLibraryStatus(null), 3000);
  };

  const isRtl = result?.language === 'fa' || /[\u0600-\u06FF]/.test(originalPrompt);

  return (
    <div className="space-y-6 max-w-5xl mx-auto animate-fadeIn">
      {/* Missing API Key banner if needed */}
      {!serverStatus?.hasApiKey && (
        <ApiKeyBanner onOpenSettings={onOpenSettings} />
      )}

      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-violet-400 text-xs font-mono font-medium mb-1">
          <Wand2 className="w-3.5 h-3.5" />
          <span>PROMPT ARCHITECT &amp; ENHANCER</span>
        </div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
          AI Prompt Enhancer
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Transform rough drafts into high-yield, structured production prompts. Supports English &amp; Persian (فارسی).
        </p>
      </div>

      {/* Input Form */}
      <form onSubmit={handleImprove} className="p-4 sm:p-6 rounded-2xl bg-[#0B132B]/90 border border-slate-800 shadow-xl space-y-4">
        {/* Language selector & Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <label htmlFor="original-prompt" className="text-xs font-bold text-slate-200">
            Paste rough idea or draft prompt: <span className="text-violet-400">*</span>
          </label>

          {/* Language selector pills */}
          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800 self-start sm:self-auto">
            <span className="text-[10px] font-mono text-slate-400 px-2 flex items-center gap-1">
              <Globe className="w-3 h-3 text-cyan-400" />
              <span>Language:</span>
            </span>
            <button
              type="button"
              onClick={() => setLanguageMode('auto')}
              className={`px-2.5 py-1 text-[11px] font-medium rounded-lg transition-all ${
                languageMode === 'auto'
                  ? 'bg-cyan-500/20 text-cyan-300 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Auto
            </button>
            <button
              type="button"
              onClick={() => setLanguageMode('en')}
              className={`px-2.5 py-1 text-[11px] font-medium rounded-lg transition-all ${
                languageMode === 'en'
                  ? 'bg-cyan-500/20 text-cyan-300 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setLanguageMode('fa')}
              className={`px-2.5 py-1 text-[11px] font-medium rounded-lg transition-all ${
                languageMode === 'fa'
                  ? 'bg-violet-500/20 text-violet-300 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              فارسی (Persian)
            </button>
          </div>
        </div>

        {/* Textarea */}
        <div>
          <textarea
            id="original-prompt"
            rows={3}
            value={originalPrompt}
            onChange={(e) => setOriginalPrompt(e.target.value)}
            dir={/[\u0600-\u06FF]/.test(originalPrompt) ? 'rtl' : 'ltr'}
            placeholder="e.g. A luxury perfume on a stone with nice light... or: یک شیشه عطر لوکس روی سنگ مرمر با نور ملایم"
            className="w-full px-4 py-3 rounded-xl bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 focus:border-violet-500 focus:ring-1 focus:ring-violet-500 text-slate-100 placeholder:text-slate-500 text-xs sm:text-sm resize-none outline-none transition-all leading-relaxed"
          />
        </div>

        {/* Sample draft chips */}
        <div>
          <span className="text-[11px] font-mono text-slate-400 block mb-1.5">
            Quick draft ideas (tap to load):
          </span>
          <div className="flex flex-wrap gap-1.5">
            {samplePrompts.map((s, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setOriginalPrompt(languageMode === 'fa' ? s.fa : s.en)}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 hover:text-cyan-300 transition-all text-left"
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Goal Selector */}
        <div>
          <label className="block text-xs font-bold text-slate-200 mb-2">
            Target Enhancement Direction
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
            {goals.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => setTargetGoal(g.id)}
                className={`min-h-[44px] p-2.5 rounded-xl text-left transition-all active:scale-95 border ${
                  targetGoal === g.id
                    ? 'bg-violet-500/20 text-violet-200 border-violet-500/50 shadow-sm'
                    : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 border border-slate-800'
                }`}
              >
                <div className="text-xs font-bold text-white">{g.label}</div>
                <div className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">{g.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={loading || !originalPrompt.trim()}
            className="w-full min-h-[48px] px-6 py-3 rounded-xl bg-gradient-to-r from-violet-600 via-fuchsia-600 to-cyan-500 hover:from-violet-500 hover:to-cyan-400 text-white font-bold text-sm tracking-wide shadow-lg glow-violet active:scale-98 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Enhancing &amp; Structuring Prompt...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4" />
                <span>Enhance Prompt &amp; Extract Structured Specs</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Loading state */}
      {loading && (
        <LoadingSkeleton
          title="MOSSIO AI is analyzing optical structure and tone..."
          subtitle="Formulating subject, lighting architecture, camera optics, and negative prompt constraints"
          cardsCount={2}
        />
      )}

      {/* Error state */}
      {error && !loading && (
        <ErrorCard
          message={error.message}
          code={error.code}
          onRetry={handleImprove}
          onOpenSettings={onOpenSettings}
        />
      )}

      {/* Results View */}
      {result && !loading && (
        <div className="space-y-5 animate-fadeIn">
          {/* Main Master Enhanced Prompt Card */}
          <div className="rounded-2xl bg-[#0B132B] border border-slate-800 p-4 sm:p-6 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-violet-400" />
                <h3 className="text-sm font-bold text-white">Enhanced Production Prompt</h3>
                {result.language === 'fa' && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-violet-500/20 text-violet-300 border border-violet-500/30">
                    فارسی
                  </span>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                {onSaveToLibrary && (
                  <button
                    type="button"
                    onClick={handleSaveToLibraryClick}
                    className="min-h-[40px] px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95"
                  >
                    <FolderPlus className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{savedToLibraryStatus || 'Save to Library'}</span>
                  </button>
                )}

                <CopyButton
                  text={result.masterRewritten}
                  label="Copy Master Prompt"
                  className="bg-violet-600 hover:bg-violet-500 text-white font-bold"
                />
              </div>
            </div>

            {/* Enhanced Prompt Content Container */}
            <div
              dir={isRtl ? 'rtl' : 'ltr'}
              className="p-4 rounded-xl bg-violet-950/20 border border-violet-500/40 text-xs sm:text-sm font-mono text-slate-100 leading-relaxed select-all shadow-inner break-words"
            >
              {result.masterRewritten}
            </div>

            {/* Optional Negative Prompt with dedicated copy button */}
            {result.negativePrompt && (
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono font-semibold text-rose-400 flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5" />
                    <span>Negative Prompt (Exclusions &amp; Artifact Killers):</span>
                  </span>
                  <CopyButton text={result.negativePrompt} label="Copy Negative" className="min-h-[32px] px-2.5 text-[11px]" />
                </div>
                <p className="text-xs font-mono text-slate-300 leading-relaxed select-all">
                  {result.negativePrompt}
                </p>
              </div>
            )}
          </div>

          {/* Structured Output Breakdown (Subject, Environment, Composition, Lighting, Camera, Style, Constraints) */}
          {result.structure && (
            <div className="rounded-2xl bg-[#0B132B] border border-slate-800 p-4 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-white">Structured Prompt Anatomy</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {result.structure.subject && (
                  <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-cyan-300">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Subject &amp; Materiality</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{result.structure.subject}</p>
                  </div>
                )}

                {result.structure.environment && (
                  <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-violet-300">
                      <Layers className="w-3.5 h-3.5" />
                      <span>Environment &amp; World</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{result.structure.environment}</p>
                  </div>
                )}

                {result.structure.composition && (
                  <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-300">
                      <Maximize2 className="w-3.5 h-3.5" />
                      <span>Composition &amp; Framing</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{result.structure.composition}</p>
                  </div>
                )}

                {result.structure.lighting && (
                  <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-300">
                      <Sun className="w-3.5 h-3.5" />
                      <span>Lighting Architecture</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{result.structure.lighting}</p>
                  </div>
                )}

                {result.structure.camera && (
                  <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-300">
                      <Camera className="w-3.5 h-3.5" />
                      <span>Camera &amp; Lens Optics</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{result.structure.camera}</p>
                  </div>
                )}

                {result.structure.style && (
                  <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 space-y-1">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-fuchsia-300">
                      <Palette className="w-3.5 h-3.5" />
                      <span>Style &amp; Color Grade</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{result.structure.style}</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Alternative Style Variations */}
          {result.alternatives && result.alternatives.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>Directional Variations</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {result.alternatives.map((alt, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-[#0B132B] border border-slate-800 hover:border-slate-700 flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase block mb-1">
                        {alt.direction}
                      </span>
                      <p className="text-xs text-slate-200 font-mono line-clamp-4 leading-relaxed">
                        {alt.prompt}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex justify-end">
                      <CopyButton text={alt.prompt} label="Copy Variation" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
