import { useState, useRef, useEffect, useCallback } from 'react';
import {
  MessageSquare,
  Send,
  Sparkles,
  Trash2,
  RefreshCw,
  SlidersHorizontal,
  Plus,
  PanelLeft,
  RotateCcw,
  AlertTriangle,
  Layers,
  ChevronDown,
} from 'lucide-react';
import { sendChatMessage, ApiError } from '../../services/api';
import { ChatMessage, ServerStatus } from '../../types';
import { useConversations } from '../../hooks/useConversations';
import { ChatMessageBubble } from './chat/ChatMessageBubble';
import { ConversationSidebar } from './chat/ConversationSidebar';
import { ApiKeyBanner } from '../common/ApiKeyBanner';
import { CopyButton } from '../common/CopyButton';

interface ChatWorkspaceProps {
  onSaveToHistory: (item: {
    type: 'chat';
    title: string;
    snippet: string;
    fullData: any;
    engine?: string;
  }) => void;
  onOpenSettings?: () => void;
  serverStatus: ServerStatus | null;
}

export function ChatWorkspace({
  onSaveToHistory,
  onOpenSettings,
  serverStatus,
}: ChatWorkspaceProps) {
  const {
    conversations,
    activeConversation,
    activeId,
    createNewConversation,
    selectConversation,
    renameConversation,
    deleteConversation,
    clearCurrentMessages,
    appendMessage,
    updateCreativeContext,
  } = useConversations();

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showContextBar, setShowContextBar] = useState(false);
  const [lastFailedQuery, setLastFailedQuery] = useState<string | null>(null);
  const [error, setError] = useState<{ message: string; code?: string } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const isNearBottomRef = useRef(true);

  const starterChips = [
    'Suggest 4 lighting rigs for a luxury watch commercial',
    'How do I achieve cinematic film grain in Midjourney v6?',
    'Write a FLUX prompt for a retro-futuristic hover train in Alps',
    'What token anti-patterns should I avoid for photorealistic human portraits?',
  ];

  // Track if user is scrolling up manually so auto-scroll doesn't disrupt them
  const handleScroll = () => {
    if (!messagesContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = messagesContainerRef.current;
    isNearBottomRef.current = scrollHeight - scrollTop - clientHeight < 120;
  };

  const scrollToBottom = useCallback((force = false) => {
    if (force || isNearBottomRef.current) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  useEffect(() => {
    scrollToBottom(false);
  }, [activeConversation.messages, loading, scrollToBottom]);

  // Adjust textarea height dynamically
  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 130)}px`;
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    adjustTextareaHeight();
  };

  const handleSend = async (overrideText?: string) => {
    const query = (overrideText || input).trim();
    if (!query || loading) return;

    // Reset error state
    setError(null);
    setLastFailedQuery(null);

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: Date.now(),
    };

    // Append user message immediately
    appendMessage(activeId, userMessage);
    if (!overrideText) {
      setInput('');
      if (textareaRef.current) textareaRef.current.style.height = 'auto';
    }

    setLoading(true);
    isNearBottomRef.current = true;
    setTimeout(() => scrollToBottom(true), 50);

    // Build history for backend
    const currentMessages = activeConversation.messages;
    const messageHistoryForApi = [...currentMessages, userMessage].map((m) => ({
      role: m.role,
      content: m.content,
    }));

    try {
      const { reply } = await sendChatMessage({
        messages: messageHistoryForApi,
        creativeContext: activeConversation.creativeContext?.trim() || undefined,
      });

      const assistantMessage: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: reply,
        timestamp: Date.now(),
      };

      appendMessage(activeId, assistantMessage);

      // Save to studio history
      onSaveToHistory({
        type: 'chat',
        title: query.slice(0, 36) + '...',
        snippet: reply.slice(0, 140) + '...',
        fullData: {
          conversationId: activeId,
          query,
          reply,
          context: activeConversation.creativeContext,
        },
        engine: 'AI Chat Copilot',
      });
    } catch (err: any) {
      console.error('Chat error:', err);
      setLastFailedQuery(query);
      if (err instanceof ApiError) {
        setError({ message: err.message, code: err.code });
      } else {
        setError({ message: err?.message || 'Failed to receive response from Gemini AI.' });
      }
    } finally {
      setLoading(false);
      setTimeout(() => scrollToBottom(true), 50);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleRetry = () => {
    if (lastFailedQuery) {
      handleSend(lastFailedQuery);
    }
  };

  return (
    <div className="flex h-[calc(100vh-140px)] sm:h-[calc(100vh-130px)] rounded-2xl bg-[#080E24] border border-slate-800 shadow-2xl overflow-hidden relative animate-fadeIn">
      {/* Session Drawer / Sidebar */}
      <ConversationSidebar
        conversations={conversations}
        activeId={activeId}
        onSelectConversation={selectConversation}
        onNewConversation={() => createNewConversation()}
        onRenameConversation={renameConversation}
        onDeleteConversation={deleteConversation}
        onClearCurrentChat={() => {
          if (confirm('Reset messages in the current conversation?')) {
            clearCurrentMessages(activeId);
          }
        }}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      {/* Main Chat Interface */}
      <div className="flex-1 flex flex-col h-full min-w-0 bg-[#060B19]">
        {/* Chat Top Bar */}
        <header className="px-3.5 sm:px-5 py-3 border-b border-slate-800/80 bg-[#0B132B]/90 backdrop-blur-md flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            {/* Toggle Conversation List */}
            <button
              type="button"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              aria-label="Toggle sessions menu"
              className={`min-h-[40px] px-2.5 py-1.5 rounded-xl border flex items-center gap-1.5 text-xs font-semibold transition-all active:scale-95 ${
                sidebarOpen
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
            >
              <PanelLeft className="w-4 h-4 text-cyan-400" />
              <span className="hidden xs:inline">Sessions</span>
              <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-slate-800 text-slate-400">
                {conversations.length}
              </span>
            </button>

            {/* Active Conversation Title */}
            <div className="min-w-0">
              <h2 className="text-xs sm:text-sm font-bold text-white truncate max-w-[140px] sm:max-w-xs">
                {activeConversation.title}
              </h2>
              <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                <span className="text-cyan-400">Active</span>
                <span>·</span>
                <span>{activeConversation.messages.length} messages</span>
              </div>
            </div>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Context Pill */}
            <button
              type="button"
              onClick={() => setShowContextBar(!showContextBar)}
              title="Set studio project context"
              className={`min-h-[38px] px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                activeConversation.creativeContext
                  ? 'bg-violet-500/20 text-violet-300 border-violet-500/40'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Context</span>
            </button>

            {/* New Session Shortcut */}
            <button
              type="button"
              onClick={() => createNewConversation()}
              title="Start New Chat"
              className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-800 active:scale-95 transition-all"
            >
              <Plus className="w-4 h-4" />
            </button>

            {/* Reset Active Chat */}
            <button
              type="button"
              onClick={() => {
                if (confirm('Clear messages in this conversation?')) {
                  clearCurrentMessages(activeId);
                }
              }}
              title="Clear Active Chat"
              className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl bg-slate-900 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-800 active:scale-95 transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </header>

        {/* Project Context Drawer if enabled */}
        {showContextBar && (
          <div className="p-3 bg-[#0B132B] border-b border-violet-500/30 text-xs shrink-0 animate-in slide-in-from-top-1">
            <label className="block text-[11px] font-mono text-violet-300 mb-1">
              Active Project Context (anchors all prompts and replies)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={activeConversation.creativeContext || ''}
                onChange={(e) => updateCreativeContext(activeId, e.target.value)}
                placeholder="e.g. Designing a minimalist Scandinavian titanium mechanical watch brand..."
                className="flex-1 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-slate-200 outline-none focus:border-violet-400"
              />
              {activeConversation.creativeContext && (
                <button
                  type="button"
                  onClick={() => updateCreativeContext(activeId, '')}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-750 text-slate-400 text-xs rounded"
                >
                  Clear
                </button>
              )}
            </div>
          </div>
        )}

        {/* Missing API Key warning banner */}
        {!serverStatus?.hasApiKey && (
          <div className="p-3 shrink-0">
            <ApiKeyBanner onOpenSettings={onOpenSettings} compact />
          </div>
        )}

        {/* Scrollable Messages Feed */}
        <div
          ref={messagesContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4"
        >
          {activeConversation.messages.map((msg, idx) => (
            <ChatMessageBubble
              key={msg.id || idx}
              message={msg}
              isLatest={idx === activeConversation.messages.length - 1}
            />
          ))}

          {/* Active Generation Loading Indicator */}
          {loading && (
            <div className="flex items-start gap-3 animate-fadeIn">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-violet-600 flex items-center justify-center text-slate-950 shrink-0 animate-spin" style={{ animationDuration: '3s' }}>
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div className="p-3.5 rounded-2xl bg-[#0B132B] border border-cyan-500/40 text-xs text-cyan-300 flex items-center gap-2.5 shadow-lg glow-cyan">
                <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
                <span className="font-medium">MOSSIO AI is analyzing context and formulating prompt architecture...</span>
              </div>
            </div>
          )}

          {/* In-Chat Error & Retry Banner */}
          {error && !loading && (
            <div className="p-3.5 rounded-2xl bg-rose-950/30 border border-rose-500/40 text-xs text-rose-200 space-y-2 animate-in fade-in">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <span className="font-semibold text-rose-300">Generation Failed: </span>
                  <span className="leading-relaxed">{error.message}</span>
                </div>
              </div>
              {lastFailedQuery && (
                <div className="flex items-center gap-2 pt-1 border-t border-rose-500/20">
                  <button
                    type="button"
                    onClick={handleRetry}
                    className="min-h-[36px] px-3 py-1 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-200 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Retry Last Message</span>
                  </button>
                  <span className="text-[10px] text-slate-400">
                    Query preserved in memory
                  </span>
                </div>
              )}
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Starter Suggestion Chips (horizontal scroll on mobile) */}
        <div className="px-3.5 py-2 overflow-x-auto no-scrollbar flex items-center gap-1.5 border-t border-slate-800/60 bg-[#070D22] shrink-0">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider shrink-0 mr-1 hidden sm:inline">
            Inspirations:
          </span>
          {starterChips.map((chip, idx) => (
            <button
              key={idx}
              type="button"
              disabled={loading}
              onClick={() => handleSend(chip)}
              className="whitespace-nowrap px-3 py-1.5 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/30 text-[11px] text-slate-300 hover:text-cyan-300 transition-all active:scale-95 shrink-0"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Bottom Message Composer */}
        <footer className="p-3 sm:p-4 border-t border-slate-800/80 bg-[#0B132B]/95 backdrop-blur-lg shrink-0 pb-safe">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-end gap-2 max-w-4xl mx-auto"
          >
            <div className="flex-1 relative rounded-2xl bg-slate-900/90 border border-slate-700/80 hover:border-slate-600 focus-within:border-cyan-500 focus-within:ring-1 focus-within:ring-cyan-500 transition-all">
              <textarea
                ref={textareaRef}
                rows={1}
                value={input}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder="Ask for Midjourney prompts, lighting setups, or creative direction... (Enter to send, Shift+Enter for newline)"
                disabled={loading}
                className="w-full px-4 py-3 rounded-2xl bg-transparent text-slate-100 placeholder:text-slate-500 text-xs sm:text-sm outline-none resize-none leading-relaxed"
                style={{ maxHeight: '130px' }}
              />
            </div>

            <button
              type="submit"
              disabled={loading || !input.trim()}
              aria-label="Send message"
              className="min-h-[48px] min-w-[48px] p-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold flex items-center justify-center transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md glow-cyan active:scale-95 shrink-0"
            >
              {loading ? (
                <RefreshCw className="w-5 h-5 animate-spin text-slate-950" />
              ) : (
                <Send className="w-5 h-5 text-slate-950" />
              )}
            </button>
          </form>
          <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-1.5 px-2">
            <span>Enter sends · Shift+Enter new line</span>
            <span>Local session saved automatically</span>
          </div>
        </footer>
      </div>
    </div>
  );
}
