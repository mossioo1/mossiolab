import { useState } from 'react';
import {
  MessageSquare,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Clock,
  Sparkles,
  HardDrive,
  AlertCircle,
} from 'lucide-react';
import { Conversation } from '../../../types';

interface ConversationSidebarProps {
  conversations: Conversation[];
  activeId: string;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onRenameConversation: (id: string, newTitle: string) => void;
  onDeleteConversation: (id: string) => void;
  onClearCurrentChat: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export function ConversationSidebar({
  conversations,
  activeId,
  onSelectConversation,
  onNewConversation,
  onRenameConversation,
  onDeleteConversation,
  onClearCurrentChat,
  isOpen,
  onClose,
}: ConversationSidebarProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const startRename = (conv: Conversation) => {
    setEditingId(conv.id);
    setEditTitle(conv.title);
  };

  const handleSaveRename = (id: string) => {
    if (editTitle.trim()) {
      onRenameConversation(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const formatTime = (ts: number) => {
    const diff = Math.floor((Date.now() - ts) / 1000);
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  };

  const content = (
    <div className="flex flex-col h-full bg-[#080E24] border-r border-slate-800/80">
      {/* Top action bar */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => {
            onNewConversation();
            onClose();
          }}
          className="flex-1 min-h-[44px] px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md glow-cyan active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>New Creative Session</span>
        </button>

        <button
          type="button"
          onClick={onClose}
          aria-label="Close conversation drawer"
          className="lg:hidden min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
        <div className="px-2 pb-1.5 text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between">
          <span>Saved Sessions ({conversations.length})</span>
          <span className="text-cyan-400">Local Cache</span>
        </div>

        {conversations.map((conv) => {
          const isActive = conv.id === activeId;
          const isEditing = editingId === conv.id;

          if (isEditing) {
            return (
              <div
                key={conv.id}
                className="p-2.5 rounded-xl bg-slate-900 border border-cyan-500/50 flex items-center gap-1.5"
              >
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveRename(conv.id);
                    if (e.key === 'Escape') setEditingId(null);
                  }}
                  autoFocus
                  className="flex-1 px-2 py-1 bg-slate-950 rounded text-xs text-white outline-none border border-slate-800"
                />
                <button
                  type="button"
                  onClick={() => handleSaveRename(conv.id)}
                  className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded bg-cyan-500 text-slate-950 hover:bg-cyan-400"
                >
                  <Check className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setEditingId(null)}
                  className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded bg-slate-800 text-slate-400 hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          }

          return (
            <div
              key={conv.id}
              onClick={() => {
                onSelectConversation(conv.id);
                onClose();
              }}
              className={`group cursor-pointer p-3 rounded-xl border transition-all text-left flex items-start justify-between gap-2.5 ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/15 via-blue-500/10 to-transparent border-cyan-500/40 text-cyan-200 shadow-sm'
                  : 'bg-slate-900/60 hover:bg-slate-850 border-slate-800/80 text-slate-300'
              }`}
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <MessageSquare
                    className={`w-3.5 h-3.5 shrink-0 ${
                      isActive ? 'text-cyan-400' : 'text-slate-500 group-hover:text-slate-400'
                    }`}
                  />
                  <h4 className="text-xs font-semibold truncate tracking-tight text-white">
                    {conv.title}
                  </h4>
                </div>

                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-1">
                  <span>{conv.messages.length} msgs</span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-2.5 h-2.5" />
                    {formatTime(conv.updatedAt)}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-1 shrink-0 opacity-80 group-hover:opacity-100">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    startRename(conv);
                  }}
                  title="Rename session"
                  className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-lg hover:bg-slate-800 text-slate-400 hover:text-cyan-300"
                >
                  <Edit2 className="w-3 h-3" />
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setDeleteConfirmId(conv.id);
                  }}
                  title="Delete session"
                  className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-lg hover:bg-rose-500/20 text-slate-400 hover:text-rose-400"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Storage info & Clear Action Footer */}
      <div className="p-3 border-t border-slate-800/80 space-y-2 bg-slate-950/60">
        <div className="flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <HardDrive className="w-3 h-3 text-cyan-400" />
            <span>Local Browser Storage</span>
          </span>
          <button
            type="button"
            onClick={onClearCurrentChat}
            className="text-[10px] font-mono text-rose-400 hover:text-rose-300 underline"
          >
            Clear Active Chat
          </button>
        </div>
        <p className="text-[10px] text-slate-400 leading-relaxed">
          Sessions are preserved locally in this browser. No personal data is stored on external cloud accounts.
        </p>
      </div>

      {/* Delete confirmation modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setDeleteConfirmId(null)}
          />
          <div className="relative w-full max-w-xs rounded-2xl bg-[#0B132B] border border-rose-500/40 p-5 shadow-2xl space-y-3 z-10 animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-2 text-rose-400">
              <AlertCircle className="w-5 h-5" />
              <h4 className="text-sm font-bold text-white">Delete Conversation?</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              This conversation history will be permanently removed from this device.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 min-h-[38px] rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteConversation(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="flex-1 min-h-[38px] rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Mobile Drawer Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
            onClick={onClose}
            aria-hidden="true"
          />
          <div className="relative w-[300px] max-w-[85vw] h-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {content}
          </div>
        </div>
      )}

      {/* Desktop slide-out sidebar or toggleable panel */}
      {isOpen && (
        <div className="hidden lg:block w-72 shrink-0 border-r border-slate-800/80 h-full">
          {content}
        </div>
      )}
    </>
  );
}
