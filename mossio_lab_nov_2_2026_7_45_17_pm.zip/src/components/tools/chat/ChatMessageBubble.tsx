import { Bot, User, Copy, Check } from 'lucide-react';
import { ChatMessage } from '../../../types';
import { CopyButton } from '../../common/CopyButton';

interface ChatMessageBubbleProps {
  message: ChatMessage;
  isLatest?: boolean;
}

export function ChatMessageBubble({ message, isLatest = false }: ChatMessageBubbleProps) {
  const isUser = message.role === 'user';

  // Format timestamp
  const timeFormatted = new Date(message.timestamp).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
  });

  // Render markdown code blocks gracefully
  const renderContent = (content: string) => {
    // Split by code blocks: ```lang ... ```
    const codeBlockRegex = /```([\s\S]*?)```/g;
    const parts = [];
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(content)) !== null) {
      // Preceding text
      if (match.index > lastIndex) {
        parts.push({
          type: 'text' as const,
          val: content.slice(lastIndex, match.index),
        });
      }

      // Code block content
      const blockText = match[1];
      // Check if first line has language tag
      const lines = blockText.split('\n');
      const firstLine = lines[0].trim();
      const hasLang = /^[a-zA-Z0-9_-]+$/.test(firstLine);
      const codeOnly = hasLang ? lines.slice(1).join('\n') : blockText;
      const lang = hasLang ? firstLine : 'prompt';

      parts.push({
        type: 'code' as const,
        lang,
        val: codeOnly.trim(),
      });

      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < content.length) {
      parts.push({
        type: 'text' as const,
        val: content.slice(lastIndex),
      });
    }

    return (
      <div className="space-y-2.5">
        {parts.map((p, idx) => {
          if (p.type === 'code') {
            return (
              <div
                key={idx}
                className="rounded-xl overflow-hidden bg-slate-950 border border-slate-800 my-2 shadow-inner"
              >
                <div className="flex items-center justify-between px-3 py-1.5 bg-slate-900/90 border-b border-slate-800 text-[10px] font-mono text-slate-400">
                  <span className="uppercase text-cyan-400">{p.lang}</span>
                  <CopyButton text={p.val} label="Copy Prompt" className="min-h-[30px] px-2 py-1 text-[10px]" />
                </div>
                <pre className="p-3 font-mono text-[11px] sm:text-xs text-cyan-200 overflow-x-auto whitespace-pre-wrap select-all leading-relaxed">
                  {p.val}
                </pre>
              </div>
            );
          }

          // Plain text with inline markdown bold (**bold**) and inline backticks (`code`)
          return (
            <p key={idx} className="whitespace-pre-wrap leading-relaxed break-words">
              {p.val}
            </p>
          );
        })}
      </div>
    );
  };

  return (
    <div
      className={`flex items-start gap-2.5 sm:gap-3.5 ${
        isUser ? 'flex-row-reverse' : 'flex-row'
      } group animate-fadeIn`}
    >
      {/* Avatar */}
      <div
        className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center shrink-0 ${
          isUser
            ? 'bg-blue-600 text-white shadow-sm'
            : 'bg-gradient-to-tr from-cyan-500 via-blue-600 to-violet-600 text-slate-950 shadow-md glow-cyan'
        }`}
      >
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-white" />}
      </div>

      {/* Bubble Container */}
      <div
        className={`max-w-[88%] sm:max-w-[80%] rounded-2xl p-3.5 sm:p-4 text-xs sm:text-sm shadow-md transition-all ${
          isUser
            ? 'bg-blue-600 text-white rounded-tr-sm shadow-blue-900/20'
            : 'bg-[#0B132B] text-slate-200 border border-slate-800/90 rounded-tl-sm shadow-xl'
        }`}
      >
        {renderContent(message.content)}

        {/* Footer info: Timestamp & Quick Action */}
        <div
          className={`flex items-center justify-between gap-3 pt-2 mt-2 border-t text-[10px] font-mono ${
            isUser ? 'border-blue-500/40 text-blue-200' : 'border-slate-800/80 text-slate-400'
          }`}
        >
          <span>{isUser ? 'You' : 'MOSSIO AI'} · {timeFormatted}</span>
          {!isUser && (
            <CopyButton
              text={message.content}
              iconOnly
              className="min-h-[28px] min-w-[28px] bg-slate-900/90 border-slate-800 text-slate-300"
            />
          )}
        </div>
      </div>
    </div>
  );
}
