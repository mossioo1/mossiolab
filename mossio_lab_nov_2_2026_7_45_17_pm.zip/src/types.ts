export type ToolTab = 'dashboard' | 'generator' | 'improver' | 'ideas' | 'chat' | 'library' | 'history' | 'settings';

export type PromptEngine = 'midjourney' | 'flux' | 'dalle3' | 'llm-system' | 'ui-ux' | 'creative-copy';

export interface GeneratedPrompt {
  id: string;
  title: string;
  variantName: string;
  mainPrompt: string;
  negativePrompt?: string;
  technicalParameters?: string;
  whyItWorks?: string;
  tags?: string[];
}

export interface PromptGenerationResult {
  summary: string;
  prompts: GeneratedPrompt[];
}

export interface StructuredPromptBreakdown {
  subject?: string;
  environment?: string;
  composition?: string;
  lighting?: string;
  camera?: string;
  style?: string;
  constraints?: string;
}

export interface PromptImprovementResult {
  original: string;
  masterRewritten: string;
  negativePrompt?: string;
  language?: 'en' | 'fa';
  structure?: StructuredPromptBreakdown;
  improvements: string[];
  alternatives: {
    direction: string;
    prompt: string;
  }[];
  proTips: string[];
}

export interface CreativeConcept {
  id: string;
  title: string;
  hook: string;
  narrative: string;
  visualDirection: string;
  deliverables?: string[];
  recommendedPrompt: string;
  category?: string;
}

export interface CreativeIdeasResult {
  campaignTitle: string;
  coreThesis: string;
  concepts: CreativeConcept[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface Conversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
  creativeContext?: string;
}

export type HistoryItemType = 'prompt' | 'improvement' | 'idea' | 'chat';

export interface HistoryItem {
  id: string;
  type: HistoryItemType;
  title: string;
  snippet: string;
  fullData: any;
  timestamp: number;
  engine?: string;
}

export type LibraryItemType = 'prompt' | 'enhancement' | 'idea';

export interface LibraryItem {
  id: string;
  type: LibraryItemType;
  title: string;
  content: string;
  negativePrompt?: string;
  category: string;
  tags?: string[];
  notes?: string;
  isFavorite: boolean;
  createdAt: number;
  updatedAt: number;
  metadata?: any;
}

export interface ServerStatus {
  status: string;
  workspace: string;
  hasApiKey: boolean;
  model: string;
  uptime: number;
  timestamp: string;
}

export interface ConnectionTestResult {
  success: boolean;
  configured: boolean;
  latencyMs?: number;
  model: string;
  reply?: string;
  errorCode?: string | number;
  message: string;
  testedAt: string;
}
