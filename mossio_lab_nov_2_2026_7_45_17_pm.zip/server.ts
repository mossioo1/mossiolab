import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Helper to get Gemini client
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey.trim() === '' || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey: apiKey.trim(),
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const PRIMARY_MODEL = 'gemini-3.1-flash-lite';
const FALLBACK_MODEL = 'gemini-3.8-flash';

// Robust generator with automatic fallback across supported Flash models and backoff
async function generateWithAdaptiveModel(
  ai: GoogleGenAI,
  params: {
    contents: any;
    config?: any;
  }
): Promise<{ response: any; modelUsed: string }> {
  const candidateModels = [PRIMARY_MODEL, FALLBACK_MODEL];
  let lastError: any = null;

  for (const model of candidateModels) {
    let attempt = 0;
    while (attempt <= 1) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: params.contents,
          config: params.config,
        });
        return { response, modelUsed: model };
      } catch (err: any) {
        lastError = err;
        attempt++;
        const isTransient =
          err?.status === 503 ||
          err?.status === 429 ||
          err?.message?.includes('503') ||
          err?.message?.includes('high demand') ||
          err?.message?.includes('UNAVAILABLE') ||
          err?.message?.includes('RESOURCE_EXHAUSTED');

        if (isTransient && attempt <= 1) {
          await new Promise((r) => setTimeout(r, 1000));
          continue;
        }
        // If transient and retried, break to try the alternate model
        if (isTransient) break;
        throw err;
      }
    }
  }

  throw lastError;
}

// 1. Health & Config Status endpoint
app.get('/api/status', (req, res) => {
  const hasApiKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY');
  res.json({
    status: 'online',
    workspace: 'MOSSIO LAB',
    hasApiKey,
    model: PRIMARY_MODEL,
    fallbackModel: FALLBACK_MODEL,
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

// Real active connectivity test endpoint
app.post('/api/test-connection', async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) {
    return res.json({
      success: false,
      configured: false,
      message: 'GEMINI_API_KEY secret is not configured in this environment.',
      model: PRIMARY_MODEL,
      testedAt: new Date().toISOString(),
    });
  }

  const startTime = Date.now();
  try {
    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Connection test timed out after 15 seconds')), 15000)
    );

    const generatePromise = ai.models.generateContent({
      model: PRIMARY_MODEL,
      contents: 'Ping. Reply with: PONG',
    });

    const response = await Promise.race([generatePromise, timeoutPromise]);

    const latencyMs = Date.now() - startTime;
    const replyText = (response.text || '').trim();

    return res.json({
      success: true,
      configured: true,
      latencyMs,
      model: PRIMARY_MODEL,
      reply: replyText,
      message: `Connection verified. ${PRIMARY_MODEL} responded successfully.`,
      testedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    const latencyMs = Date.now() - startTime;
    console.error('Gemini connection test failed:', err);

    let cleanMessage = 'Failed to connect to Google Gemini API.';
    let errorCode = err?.status || err?.code || 'CONNECTION_ERROR';

    let rawMessage = err?.message || '';
    try {
      const parsed = JSON.parse(rawMessage);
      if (parsed?.error?.message) {
        rawMessage = parsed.error.message;
      }
    } catch (_) {}

    if (rawMessage.includes('API_KEY_INVALID') || err?.status === 400) {
      cleanMessage = 'The provided API key was rejected as invalid by Google API servers.';
      errorCode = 'API_KEY_INVALID';
    } else if (rawMessage.includes('PERMISSION_DENIED') || err?.status === 403) {
      cleanMessage = 'Permission denied. Verify key permissions in Google AI Studio.';
      errorCode = 'PERMISSION_DENIED';
    } else if (rawMessage.includes('RESOURCE_EXHAUSTED') || err?.status === 429) {
      cleanMessage = 'API quota exceeded or rate limit reached.';
      errorCode = 'RESOURCE_EXHAUSTED';
    } else if (rawMessage.includes('high demand') || err?.status === 503) {
      cleanMessage = 'Gemini models are temporarily experiencing high server demand (503). Retrying usually clears within moments.';
      errorCode = 503;
    } else if (rawMessage) {
      cleanMessage = rawMessage.replace(/AIza[0-9A-Za-z-_]{35}/g, '[REDACTED_KEY]');
    }

    return res.json({
      success: false,
      configured: true,
      latencyMs,
      errorCode,
      message: cleanMessage,
      model: PRIMARY_MODEL,
      testedAt: new Date().toISOString(),
    });
  }
});

// Helper error response for missing credentials
function sendMissingKeyResponse(res: express.Response) {
  return res.status(401).json({
    error: 'API_KEY_NOT_CONFIGURED',
    message: 'Gemini API key is not configured in this environment.',
    details: 'To activate live AI features on MOSSIO LAB, open the AI Studio "Secrets" panel (or configure GEMINI_API_KEY in your environment) with a valid Google Gemini API key.',
  });
}

// 2. Prompt Generator Endpoint
app.post('/api/ai/generate-prompt', async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return sendMissingKeyResponse(res);

  const {
    concept,
    toolType = 'midjourney',
    style = 'Cinematic Film',
    aspectRatio = '16:9',
    mood = 'Dramatic & Atmospheric',
    lighting = 'Volumetric rim light with neon rim glow',
    camera = '35mm anamorphic prime lens, shallow depth of field',
  } = req.body;

  if (!concept || typeof concept !== 'string' || !concept.trim()) {
    return res.status(400).json({ error: 'INVALID_INPUT', message: 'A prompt concept or idea is required.' });
  }

  try {
    const prompt = `You are the lead prompt engineer at MOSSIO LAB, a world-class creative AI studio.
Synthesize the user's idea into 3 masterfully crafted, high-performance creative prompts tailored for ${toolType}.

Input Concept: "${concept.trim()}"
Creative Profile:
- Target Engine: ${toolType}
- Visual/Output Style: ${style}
- Aspect Ratio: ${aspectRatio}
- Mood/Tone: ${mood}
- Lighting: ${lighting}
- Composition/Framing: ${camera}

Respond ONLY in valid, parseable JSON with the following schema:
{
  "summary": "Brief executive summary of the aesthetic direction",
  "prompts": [
    {
      "id": "p-1",
      "title": "Clear creative title for prompt 1",
      "variantName": "Production Master",
      "mainPrompt": "The full, rich prompt ready to copy-paste",
      "negativePrompt": "Terms to exclude (if applicable for image engines)",
      "technicalParameters": "--ar ${aspectRatio} --v 6.1 --style raw --q 2",
      "whyItWorks": "1-2 sentences on why this prompt structure succeeds",
      "tags": ["Tag1", "Tag2", "Tag3"]
    },
    {
      "id": "p-2",
      "title": "Clear creative title for prompt 2",
      "variantName": "Hyper-Detailed & Atmospheric",
      "mainPrompt": "Second distinct variation pushing depth, lighting and tactile materials",
      "negativePrompt": "Terms to exclude",
      "technicalParameters": "--ar ${aspectRatio} --stylize 250",
      "whyItWorks": "1-2 sentences on why this prompt structure succeeds",
      "tags": ["Tag1", "Tag2", "Tag3"]
    },
    {
      "id": "p-3",
      "title": "Clear creative title for prompt 3",
      "variantName": "Avant-Garde & Conceptual",
      "mainPrompt": "Third striking bold variation with unique artistic framing",
      "negativePrompt": "Terms to exclude",
      "technicalParameters": "--ar ${aspectRatio} --chaos 15",
      "whyItWorks": "1-2 sentences on why this prompt structure succeeds",
      "tags": ["Tag1", "Tag2", "Tag3"]
    }
  ]
}`;

    const { response } = await generateWithAdaptiveModel(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error generating prompt:', error);
    return res.status(500).json({
      error: 'GENERATION_FAILED',
      message: error?.message || 'Failed to generate prompts. Please try again.',
    });
  }
});

// 3. Prompt Enhancer Endpoint (supports structured breakdown, Persian & English, negative prompt)
app.post('/api/ai/improve-prompt', async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return sendMissingKeyResponse(res);

  const {
    originalPrompt,
    targetGoal = 'Photorealistic Realism',
    targetEngine = 'image',
    language = 'auto',
  } = req.body;

  if (!originalPrompt || typeof originalPrompt !== 'string' || !originalPrompt.trim()) {
    return res.status(400).json({ error: 'INVALID_INPUT', message: 'Original prompt text is required to enhance.' });
  }

  // Detect Persian characters if auto
  const hasPersian = /[\u0600-\u06FF]/.test(originalPrompt);
  const effectiveLanguage = language === 'fa' || (language === 'auto' && hasPersian) ? 'fa' : 'en';

  try {
    const prompt = `You are the lead Prompt Enhancement Architect at MOSSIO LAB.
Analyze this user-submitted draft and dramatically upgrade its fidelity, atmospheric depth, and technical precision.

Input Prompt: "${originalPrompt.trim()}"
Optimization Goal: ${targetGoal}
Target Engine Domain: ${targetEngine}
Language Mode: ${effectiveLanguage === 'fa' ? 'Persian (Farsi). If Persian, write the master prompt and structured breakdown in Persian or bilingual with universal English render tokens where beneficial.' : 'English'}

Provide a comprehensive, production-grade enhancement with:
1. "masterRewritten": Complete, high-yield enhanced prompt ready for AI generation.
2. "negativePrompt": Tailored negative terms to eliminate artifacts and low-quality results.
3. "structure": Structured breakdown containing:
   - "subject": Key subject details, materials, and clothing/textures.
   - "environment": World setting, backdrop, atmosphere, and era.
   - "composition": Framing, angle, rule of thirds, perspective.
   - "lighting": Key light, rim light, volumetric glow, shadows.
   - "camera": Lens, aperture, sensor, aspect ratio, depth of field.
   - "style": Visual aesthetic, art movement, film stock, color grade.
   - "constraints": Prohibitions and quality anchors.
4. "improvements": 3-4 specific token enhancements applied.
5. "alternatives": 3 directional variations ("Cinematic Realism", "Minimalist Concept", "Technical Spec").
6. "proTips": 2-3 actionable tips for this prompt.

Respond ONLY in valid, parseable JSON matching this schema:
{
  "original": "${originalPrompt.trim().replace(/"/g, '\\"')}",
  "masterRewritten": "The enhanced production-ready master prompt",
  "negativePrompt": "blurry, low resolution, artifacts, distorted, flat lighting, text, watermark",
  "language": "${effectiveLanguage}",
  "structure": {
    "subject": "Detailed subject specs",
    "environment": "Detailed atmospheric setting specs",
    "composition": "Framing and perspective specs",
    "lighting": "Lighting architecture specs",
    "camera": "Lens and camera parameters",
    "style": "Stylistic aesthetic and film stock",
    "constraints": "Quality anchors and exclusions"
  },
  "improvements": [
    "Improvement 1",
    "Improvement 2",
    "Improvement 3"
  ],
  "alternatives": [
    {
      "direction": "Cinematic Realism",
      "prompt": "Prompt variation..."
    },
    {
      "direction": "Minimalist High-Concept",
      "prompt": "Prompt variation..."
    },
    {
      "direction": "Technical Precision",
      "prompt": "Prompt variation..."
    }
  ],
  "proTips": [
    "Tip 1",
    "Tip 2"
  ]
}`;

    const { response } = await generateWithAdaptiveModel(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error enhancing prompt:', error);
    return res.status(500).json({
      error: 'IMPROVEMENT_FAILED',
      message: error?.message || 'Failed to enhance prompt. Please try again.',
    });
  }
});

// 4. Creative Idea Generator Endpoint (supports image, video, storytelling, branding, architecture, game concepts, general creativity, count)
app.post('/api/ai/creative-ideas', async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return sendMissingKeyResponse(res);

  const {
    topic,
    category = 'image',
    tone = 'High-end, provocative, modern tech',
    vibe,
    targetAudience = 'Creative directors, founders, and designers',
    count = 4,
  } = req.body;

  const effectiveTone = tone || vibe || 'High-end, provocative, modern tech';
  const effectiveCount = Math.max(2, Math.min(8, Number(count) || 4));

  if (!topic || typeof topic !== 'string' || !topic.trim()) {
    return res.status(400).json({ error: 'INVALID_INPUT', message: 'Topic or project context is required.' });
  }

  try {
    const prompt = `You are the Executive Creative Director at MOSSIO LAB.
Generate exactly ${effectiveCount} distinctive, non-generic, high-impact creative concepts for the following brief:

Topic/Context: "${topic.trim()}"
Category Domain: ${category} (e.g. image, video, storytelling, branding, architecture, game concepts, general creativity)
Tone/Vibe: ${effectiveTone}
Target Audience: ${targetAudience}

Avoid generic clichés or standard template fluff. Generate fresh, culturally resonant, high-taste creative angles.

Return ONLY valid JSON matching this schema:
{
  "campaignTitle": "A gripping overarching theme title",
  "coreThesis": "1-2 sentences capturing the bold strategic vision",
  "concepts": [
    ${Array.from({ length: effectiveCount })
      .map(
        (_, i) => `{
      "id": "c-${i + 1}",
      "title": "Distinctive Concept Title ${i + 1}",
      "hook": "Sharp 1-line hook or tagline",
      "narrative": "Detailed narrative concept and emotional hook",
      "visualDirection": "Specific sensory and visual cues (lighting, color palette, staging)",
      "deliverables": ["Deliverable 1", "Deliverable 2"],
      "recommendedPrompt": "A ready-to-run prompt to visualize this concept in AI",
      "category": "${category}"
    }`
      )
      .join(',\n    ')}
  ]
}`;

    const { response } = await generateWithAdaptiveModel(ai, {
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    return res.json(parsed);
  } catch (error: any) {
    console.error('Error generating ideas:', error);
    return res.status(500).json({
      error: 'IDEAS_FAILED',
      message: error?.message || 'Failed to generate creative concepts.',
    });
  }
});

// 5. Creative AI Chat Copilot Endpoint
app.post('/api/ai/chat', async (req, res) => {
  const ai = getGeminiClient();
  if (!ai) return sendMissingKeyResponse(res);

  const { messages, creativeContext } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: 'INVALID_INPUT', message: 'Chat messages are required.' });
  }

  try {
    const systemInstruction = `You are MOSSIO LAB AI, an elite creative partner and studio director specializing in high-end design, photography direction, Midjourney/FLUX prompt architecture, brand positioning, and visual storytelling.
You provide concrete, practical, taste-informed answers. When suggesting prompts, format them inside distinct markdown code blocks so the user can easily copy them. Keep answers sharp, structured, and insightful. Avoid fluffy conversational filler.`;

    const contents = messages.map((m: any) => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: [{ text: String(m.content) }],
    }));

    if (creativeContext) {
      contents.unshift({
        role: 'user',
        parts: [{ text: `[Active Studio Context]: ${creativeContext}` }],
      });
      contents.splice(1, 0, {
        role: 'model',
        parts: [{ text: `Understood. Working within your active studio context.` }],
      });
    }

    const { response } = await generateWithAdaptiveModel(ai, {
      contents,
      config: {
        systemInstruction,
      },
    });

    const reply = response.text || 'I was unable to generate a response. Please refine your query.';
    return res.json({ reply });
  } catch (error: any) {
    console.error('Error in chat endpoint:', error);
    return res.status(500).json({
      error: 'CHAT_FAILED',
      message: error?.message || 'Chat request failed. Check server connection.',
    });
  }
});

// Production static assets or Vite middleware in dev
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`MOSSIO LAB Server listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start MOSSIO LAB server:', err);
  process.exit(1);
});
